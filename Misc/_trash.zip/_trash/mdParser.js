//------------------------------------------------------------------------
//mdParser.js 
//------------------------------------------------------------------------
function mdParser(title, bodyTxt) {
      this.title = title;
      this.bodyTxt = bodyTxt;
      this.GetHtml = function() {
            var a = '<!DOCTYPE html>';
            a += '<html>';
            a += '<title>';
            var b = '</title>';
            b += '<meta charset="utf-8">'
            b += '<xmp theme="cerulean" style="display:none;">'
            var c = '</xmp>';
            c += '<script src="build/strapdown.min.js"></script>';
            c += '</html>';
            return a + this.title + b + this.bodyTxt + c;
         } //end mdParser.GetHtml
   } //end.mdParser