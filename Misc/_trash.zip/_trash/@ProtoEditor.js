cfg.Fast
app.SetOptions("AllowRemote,IgnoreErrors")

//------------------------------------------------------------------------
// UnifiedProtoEditor.js - All-in-one version
// ProtoMerged v3.0.0
//------------------------------------------------------------------------

// Global variables
var mybuttons = [];
var barAHeight = 0.09;
var barBHeight = 0.09;
var keyBarHeight = 0.09;
var titleBarHeight = 0.09;
var codEdit;
var isEdtA = false;
var isEdtB = false;

// Initialize app
app.SaveBoolean("isDebug", false);
if (!app.LoadBoolean("isLocked", false, "isLocked.txt")) {
   app.SetOrientation(app.GetOrientation());
   app.ShowPopup("🔐");
} else {
   app.ShowPopup("🔓");
}

//------------------------------------------------------------------------
// Main entry point
//------------------------------------------------------------------------
function OnStart() {
   // Initialize Performance Optimizer
   optimizer = new performanceOptimizer();
   optimizer.init();
   optimizer.optimizeStartup();

   if (app.LoadBoolean("isLocked", null, "isLocked.txt")) {
      app.SaveBoolean("isConfig", false, "isConfig.txt");
   } else {
      app.SaveBoolean("isConfig", true, "isConfig.txt");
   }

   app.SaveBoolean("isProtected", true, "isProtected.txt");

   // Initialize keyboard handler
   new keybd();
   app.SetOnShowKeyboard(function() {
      keybd.init();
   });

   // Set theme
   setTheme();

   // Create loading dialog
   app.LoadPlugin("Support");
   sup = app.CreateSupport();
   layps = app.CreateLayout("linear", "Vertical");
   layps.SetMargins(0.018, 0.018, 0.018, 0.018);
   laypp = app.CreateLayout("Linear");
   laypp.SetBackColor("#363636");
   laypp.AddChild(layps);
   prg = sup.CreateProgress();
   prg.SetSpinSpeed(Math.PI/9);
   prg.SetBarColor("#783873");
   prg.SetRimColor("#2c2b2a");
   prg.SetRimWidth(8.91);
   prg.SetCircleRadius(.27);
   prg.SetBarWidth(9);
   prg.SetSpin(true);
   layps.AddChild(prg);
   dlgpp = sup.CreateBottomSheet(1, .65);
   dlgpp.AddChild(laypp);
   dlgpp.Show();
   txtUpdate = app.CreateText("Booting...", 1, -1, "MultiLine");
   txtUpdate.SetPadding(.0108, .0108, .0108, .0108);
   layps.AddChild(txtUpdate);

   if (app.IsAPK()) {
      app.SetSharedApp(app.GetAppName());
   }

   txtUpdate.SetText('Ops Config...');

   // Configure options
   new opts();
   opts.config();

   txtUpdate.SetText('Configuring hardware keys...');
   hwShorts();

   txtUpdate.SetText('Making multiedit...');
   var medit = new multiEdit();
   var med = medit.init();
   dlgmult = app.CreateDialog("medit", "NoDim,OverKeys");
   dlgmult.AddLayout(med);

   txtUpdate.SetText("Ops Extract");
   opts.extract();

   // Build UI
   build();

   // Initialize drawers
   new drawer();
   txtUpdate.SetText('Initializing clipboard / utility drawer...');
   drawer.buildRight();
   txtUpdate.SetText('Initializing file drawer...');
   drawer.buildLeft();

   if (!app.LoadBoolean("assetsExt", false, "assetsExt.txt")) {
      opts.dlgWs.Show();
      app.SaveBoolean("assetsExt", true, "assetsExt.txt");
   }

   // Initialize Git integration
   git = new gitIntegration();
   git.init();

   // Initialize Cloud Storage integration
   cloud = new cloudStorage();
   cloud.init();

   // Initialize Terminal/Console
   terminal = new terminalConsole();
   terminal.init();

   if (app.LoadBoolean("isFirstBoot", true, "isFirstBoot.txt")) {
      window.OnBack();
      window.OnBack();
      window.OnBack();
      app.SaveBoolean("isFirstBoot", false, "isFirstBoot.txt");
      dlgpp.Dismiss();
   }
} //end.OnStart

//------------------------------------------------------------------------
// Build the main UI
//------------------------------------------------------------------------
function build() {
   layM = app.CreateLayout("linear");
   setTheme();
   txtUpdate.SetText('Creating title bar...');

   new titleBar();
   var titleB = titleBar.CreateTitleBar("ProtoEditor", 16);
   titleB.h = titleBarHeight;
   titleBar.SetStyle(titleBarHeight, .27, "#2c2b2a", "#383873", "#793939", "#2c2b2a", -1);
   layM.AddChild(titleB);

   txtUpdate.SetText('Building menubar A...');
   var ebarA = new editorBarA();
   ebarA.h = barAHeight;
   layM.edtBarA = ebarA.init(ebarA.h);
   layM.AddChild(layM.edtBarA);

   txtUpdate.SetText('Creating code editor...');
   codEdit = new codeEditor();
   codEdit.hSum = parseFloat(1 - (barAHeight + barBHeight + titleBarHeight + keyBarHeight + 0.045));
   layM.codeEdit = codEdit.init(codEdit.hSum);
   layM.AddChild(layM.codeEdit);

   txtUpdate.SetText('Building menubar B...');
   var ebarB = new editorBarB();
   ebarB.h = barBHeight;
   layM.edtBarB = ebarB.init(ebarB.h);
   layM.AddChild(layM.edtBarB);

   txtUpdate.SetText('Initializing key shortcut bar...');
   var pathKeys = app.LoadText("pathDat", (app.GetAppPath() + "/user/"), "pathDat.txt") + "/keys.txt";
   var keys = app.ReadFile(pathKeys);
   keybar = new extraKeyBar();
   keybar.init(keyBarHeight);
   keybar.SetKeys(app.ReadFile(pathKeys));
   var extbar = keybar.GetExtraKeyBar(edtTxt);

   layM.AddChild(extbar);
   app.AddLayout(layM);

   txtUpdate.SetText('Building docsviewer');
   new docs();
   docs.build();
   dlgpp.Dismiss();
} //end.build

//------------------------------------------------------------------------
// Touch handlers for buttons
//------------------------------------------------------------------------
// Variable to track fullscreen mode state
var isFullscreenMode = false;

function keys_OnTouch() {
      switch (this.icon) {
         case "[fa-undo]":
            edtTxt.Undo();
            break;
         case "[fa-close]":
            edtTxt.SetText(" ");
            break;
         case "[fa-copy]":
            edtTxt.Copy()
            break;
         case "[fa-paste]":
            edtTxt.Paste();
            break;
         case "[fa-arrows-alt]":
            edtTxt.SelectAll();
            break;
         case "[fa-play]":
            var syntax = spnSyntax.GetText();
            app.SaveBoolean("isDebug", false);
            run(syntax);
            break;
         case "[fa-lock]":
            if (!app.LoadBoolean("isLocked", false, "isLocked.txt")) {
               app.SaveBoolean("isLocked", true, "isLocked.txt");
               app.SaveBoolean("isConfig", false, "isConfig.txt");
               app.SetOrientation(app.GetOrientation());
               app.ShowPopup("🔐");
            } else {
               app.SaveBoolean("isLocked", false, "isLocked.txt");
               app.SaveBoolean("isConfig", true, "isConfig.txt");
               app.SetOrientation(app.GetOrientation());
               app.ShowPopup("🔓");
            }
            break;
         case "[fa-share-alt]":
            app.SendText(edtTxt.GetText());
            break;
         case "[fa-bars]":
            app.OpenDrawer("left");
            break;
         case "[fa-folder-open]":
            var oldFile = app.LoadText("currentFile", null, "currentFile.txt");
            app.SaveText("lastFile", oldFile, "lastFile.txt");
            openFile()
            app.CloseDrawer("left");
            break;
         case "[fa-bug]":
            var syntax = spnSyntax.GetText();
            app.SaveBoolean("isDebug", true);
            run(syntax);
            break;
         case "[fa-chrome]":
            var file = app.LoadText("currentFile", null, "currentFile.txt");
            if (file.indexOf(".html") > -1) {
               web.LoadUrl("file://" + file);
               webd.Show();
            } else {
               app.OpenUrl("http://www.google.com");
            }
            break;
         // Theme toggle functionality
         case "[fa-adjust]":
            toggleTheme();
            break;
         // Toggle fullscreen mode
         case "[fa-expand]":
            toggleFullscreenMode();
            break;
         // Open Git panel
         case "[fa-git]":
            git.showGitPanel();
            break;
         // Open Cloud Storage panel
         case "[fa-cloud]":
            cloud.showCloudPanel();
            break;
         // Open Terminal panel
         case "[fa-terminal]":
            terminal.showTerminalPanel();
            break;
      } //end.switch
} //end.keys_OnTouch

// Function to toggle fullscreen mode
function toggleFullscreenMode() {
    isFullscreenMode = !isFullscreenMode;

    if (isFullscreenMode) {
        // Hide UI elements for fullscreen mode
        titleB.SetVisibility("Gone");
        layM.edtBarA.SetVisibility("Gone");
        layM.edtBarB.SetVisibility("Gone");
        keybar.GetExtraKeyBar(edtTxt).SetVisibility("Gone");

        // Resize editor to take full screen
        var newHeight = parseFloat(1 - 0.045); // Leave a small area for the exit button
        layM.codeEdit.SetSize(1, newHeight);

        // Create a small exit fullscreen button
        if (!window.exitFullscreenBtn) {
            window.exitFullscreenBtn = app.CreateButton("[fa-compress]", 0.15, 0.045, "FontAwesome");
            window.exitFullscreenBtn.SetPosition(0.85, 0);
            window.exitFullscreenBtn.SetOnTouch(toggleFullscreenMode);
            app.AddLayout(window.exitFullscreenBtn);
        } else {
            window.exitFullscreenBtn.SetVisibility("Show");
        }

        app.ShowPopup("Fullscreen mode enabled");
    } else {
        // Restore UI elements
        titleB.SetVisibility("Show");
        layM.edtBarA.SetVisibility("Show");
        layM.edtBarB.SetVisibility("Show");
        keybar.GetExtraKeyBar(edtTxt).SetVisibility("Show");

        // Restore original size
        var originalHeight = parseFloat(1 - (barAHeight + barBHeight + titleBarHeight + keyBarHeight + 0.045));
        layM.codeEdit.SetSize(1, originalHeight);

        // Hide exit button
        if (window.exitFullscreenBtn) {
            window.exitFullscreenBtn.SetVisibility("Gone");
        }

        app.ShowPopup("Fullscreen mode disabled");
    }
}

function keys_OnLTouch() {
      switch (this.icon) {
         case "[fa-save]":
            if (!(app.LoadBoolean("isProtected", false, "isProtected.txt"))) {
               var file = app.LoadText("currentFile", null, "currentFile.txt");
               app.WriteFile(file, app.ReadFile(file));
               app.WriteFile(file, edtTxt.GetText());
               app.ShowPopup("Saved:" + " \n" + file);
            }
            break;
         case "[fa-play]":
            app.SaveBoolean("isDebug", false);
            run("quicksand")
            break;
         case "[fa-exchange]":
            edtTxt.ReplaceAll(searchF.GetText(), searchR.GetText());
            break;
      } //end.switch
} //end.keys_OnLTouch

//------------------------------------------------------------------------
// Theme functionality
//------------------------------------------------------------------------
function setTheme(themeName) {
      // Default to the saved theme or dark if none is saved
      var currentTheme = themeName || app.LoadText("currentTheme", "dark", "currentTheme.txt");

      // Save the current theme
      app.SaveText("currentTheme", currentTheme, "currentTheme.txt");

      if (currentTheme === "light") {
          // Light theme
          theme = app.CreateTheme("Light");
          theme.SetDimBehind(false);
          theme.SetButtonStyle("#e0e0e0", "#c0c0c0", 2, "#f5f5f5", 0, 1, "#4a90e2");
          theme.AdjustColor(0, 0, 0);
          theme.SetBtnTextColor("#333333");
          theme.SetButtonOptions("custom");
          theme.SetBackColor("#f5f5f5");
          theme.SetCheckBoxOptions("light");
          theme.SetTextEditOptions("NoDim");
          theme.SetDialogColor("#f5f5f5");
          theme.SetDialogBtnColor("#e0e0e0");
          theme.SetDialogBtnTxtColor("#333333");

          // Set editor colors for light theme
          if (typeof edtTxt !== 'undefined') {
              edtTxt.SetColorScheme("Light");
              edtTxt.SetBackColor("#ffffff");
              edtTxt.SetTextColor("#333333");
              edtTxt.SetBackAlpha(1);
          }

          // Set line numbers colors for light theme
          if (typeof codeEditor !== 'undefined' && codeEditor.lineNumbers) {
              codeEditor.lineNumbers.SetTextColor("#777777");
              codeEditor.lineNumbers.SetBackColor("#f0f0f0");
          }

      } else {
          // Dark theme (default)
          theme = app.CreateTheme("Dark");
          theme.SetDimBehind(false);
          theme.SetButtonStyle("#353535", "#161616", 2, "#2c2b2a", 0, 1, "#978873");
          theme.AdjustColor(35, 0, -10);
          theme.SetBtnTextColor("white");
          theme.SetButtonOptions("custom");
          theme.SetBackColor("#2c2b2a");
          theme.SetCheckBoxOptions("dark");
          theme.SetTextEditOptions("NoDim");
          theme.SetDialogColor("#2c2b2a");
          theme.SetDialogBtnColor("#2c2b2a");
          theme.SetDialogBtnTxtColor("white");

          // Set editor colors for dark theme
          if (typeof edtTxt !== 'undefined') {
              edtTxt.SetColorScheme("Dark");
              edtTxt.SetBackColor("#783873");
              edtTxt.SetBackAlpha(.09);
          }

          // Set line numbers colors for dark theme
          if (typeof codeEditor !== 'undefined' && codeEditor.lineNumbers) {
              codeEditor.lineNumbers.SetTextColor("#AAAAAA");
              codeEditor.lineNumbers.SetBackColor("#222222");
          }
      }

      app.SetTheme(theme);
} //end.setTheme

// Function to toggle between light and dark themes
function toggleTheme() {
    var currentTheme = app.LoadText("currentTheme", "dark", "currentTheme.txt");
    var newTheme = (currentTheme === "dark") ? "light" : "dark";
    setTheme(newTheme);

    // Refresh UI components that need theme updates
    if (typeof titleBar !== 'undefined' && titleBar.SetStyle) {
        if (newTheme === "light") {
            titleBar.SetStyle(titleBarHeight, .27, "#f5f5f5", "#4a90e2", "#e0e0e0", "#f5f5f5", -1);
        } else {
            titleBar.SetStyle(titleBarHeight, .27, "#2c2b2a", "#383873", "#793939", "#2c2b2a", -1);
        }
    }

    // Update other UI components as needed
    if (typeof layM !== 'undefined') {
        if (typeof layM.edtBarA !== 'undefined') {
            layM.edtBarA.SetBackColor(newTheme === "light" ? "#f0f0f0" : "#2c2b2a");
        }
        if (typeof layM.edtBarB !== 'undefined') {
            layM.edtBarB.SetBackColor(newTheme === "light" ? "#f0f0f0" : "#2c2b2a");
        }
    }

    // Show confirmation to user
    app.ShowPopup("Theme changed to " + newTheme);
}

//------------------------------------------------------------------------
// Recent Files functionality
//------------------------------------------------------------------------
// Function to show a popup with recent files for quick access
function showRecentFilesPopup() {
    // Create a dialog for recent files
    var dlgRecentFiles = app.CreateDialog("Recent Files", "NoCancel");

    // Create a layout for the dialog
    var layRecent = app.CreateLayout("Linear", "Vertical");
    layRecent.SetSize(0.9, 0.6);

    // Get the list of recent files
    var recentFilesList = app.LoadText("listRecents", "", "listRecents.txt");
    var recentFiles = recentFilesList.split(",");

    // Create a list to display recent files
    var lstRecent = app.CreateList("", 0.9, 0.5);

    // Filter out empty entries and add to list
    for (var i = 0; i < recentFiles.length; i++) {
        if (recentFiles[i] && recentFiles[i].trim() !== "") {
            // Extract filename from path
            var fileName = recentFiles[i].substring(recentFiles[i].lastIndexOf("/") + 1);

            // Add file to list with full path as data
            lstRecent.AddItem(fileName, recentFiles[i]);
        }
    }

    // Set what happens when a file is selected
    lstRecent.SetOnTouch(function(title, body, type, index) {
        // body contains the full path
        onFileChoose(body);
        dlgRecentFiles.Dismiss();
    });

    // Add a search box for filtering files
    var edtSearch = app.CreateTextEdit("", 0.9, -1, "SingleLine");
    edtSearch.SetHint("Search files...");

    // Add search functionality
    edtSearch.SetOnChange(function() {
        var searchText = edtSearch.GetText().toLowerCase();

        // Clear the list
        lstRecent.RemoveAll();

        // Add matching files
        for (var i = 0; i < recentFiles.length; i++) {
            if (recentFiles[i] && recentFiles[i].trim() !== "") {
                var fileName = recentFiles[i].substring(recentFiles[i].lastIndexOf("/") + 1);

                // Check if the file name contains the search text
                if (fileName.toLowerCase().indexOf(searchText) !== -1) {
                    lstRecent.AddItem(fileName, recentFiles[i]);
                }
            }
        }
    });

    // Add a button to clear the recent files list
    var btnClear = app.CreateButton("Clear Recent Files", 0.9, -1);
    btnClear.SetOnTouch(function() {
        app.SaveText("listRecents", "", "listRecents.txt");
        lstRecent.RemoveAll();
        app.ShowPopup("Recent files list cleared");
    });

    // Add components to layout
    layRecent.AddChild(edtSearch);
    layRecent.AddChild(lstRecent);
    layRecent.AddChild(btnClear);

    // Add layout to dialog and show it
    dlgRecentFiles.AddLayout(layRecent);
    dlgRecentFiles.Show();
}
//------------------------------------------------------------------------
// Code Editor with folding and auto-indentation
//------------------------------------------------------------------------
function codeEditor() {
      this.init = function(codeEditHeight) {
         codeEditor.h = codeEditHeight
         codeEditor.w = .90

         // Create a layout to hold the line numbers, fold indicators, and code editor
         codeEditor.layout = app.CreateLayout("Linear", "Horizontal");

         // Create line numbers and fold indicators layout
         codeEditor.leftPanel = app.CreateLayout("Linear", "Horizontal");
         codeEditor.leftPanel.SetSize(0.15, codeEditor.h);

         // Create line numbers text view
         codeEditor.lineNumbers = app.CreateText("", 0.07, codeEditor.h);
         codeEditor.lineNumbers.SetTextSize(12);
         codeEditor.lineNumbers.SetTextColor("#AAAAAA");
         codeEditor.lineNumbers.SetBackColor("#222222");
         codeEditor.lineNumbers.SetPadding(0.01, 0.01, 0.01, 0.01);

         // Create fold indicators area
         codeEditor.foldIndicators = app.CreateLayout("Absolute");
         codeEditor.foldIndicators.SetSize(0.08, codeEditor.h);
         codeEditor.foldIndicators.SetBackColor("#333333");

         // Add line numbers and fold indicators to left panel
         codeEditor.leftPanel.AddChild(codeEditor.lineNumbers);
         codeEditor.leftPanel.AddChild(codeEditor.foldIndicators);

         // Create the code editor with slightly reduced width to accommodate left panel
         edtTxt = app.CreateCodeEdit("code editor", codeEditor.w - 0.15, codeEditor.h);

         // Store folding state information
         codeEditor.foldedSections = [];
         codeEditor.foldButtons = [];

         if (app.LoadBoolean("AutoOn", null, "AutoOn.txt")) {
            edtTxt.SetOnChange(refilter)
         } else {}

         // Set up the code editor
         edtTxt.SetColorScheme("Dark");
         edtTxt.SetBackColor("#783873");
         edtTxt.SetBackAlpha(.09)
         edtTxt.SetOnDoubleTap(function() {
            app.OpenDrawer("right");
         });

         // Add line number and auto-indentation functionality
         edtTxt.SetOnChange(function() {
            updateLineNumbers();
            handleAutoIndent();
         });

         // Function to update line numbers and fold indicators
         function updateLineNumbers() {
            var text = edtTxt.GetText();
            var lines = text.split("\n");
            var lineCount = lines.length;
            var lineNumbersText = "";

            // Clear existing fold buttons
            for (var i = 0; i < codeEditor.foldButtons.length; i++) {
                codeEditor.foldIndicators.RemoveChild(codeEditor.foldButtons[i]);
            }
            codeEditor.foldButtons = [];

            // Update line numbers and detect foldable sections
            for (var i = 1; i <= lineCount; i++) {
                lineNumbersText += i + "\n";

                // Check if this line is the start of a foldable section
                var line = lines[i-1].trim();

                // Check for code block start indicators
                if (line.endsWith("{") ||
                    line.match(/^(function|class|if|for|while|switch|try)\s/) ||
                    line.match(/^(def|class)\s/) || // Python
                    line.endsWith(":")) {  // Python

                    // Create fold button for this line
                    var foldBtn = app.CreateButton("[+]", 0.06, 0.04);
                    foldBtn.SetBackColor("#333333");
                    foldBtn.SetTextColor("#AAAAAA");
                    foldBtn.SetTextSize(10);

                    // Calculate position based on line number
                    var yPos = (i-1) * 0.04; // Adjust based on line height
                    foldBtn.SetPosition(0.01, yPos);

                    // Store line information with the button
                    foldBtn.startLine = i;
                    foldBtn.isFolded = false;

                    // Set up fold/unfold action
                    foldBtn.SetOnTouch(function() {
                        toggleFold(this);
                    });

                    // Add to fold indicators
                    codeEditor.foldIndicators.AddChild(foldBtn);
                    codeEditor.foldButtons.push(foldBtn);
                }
            }

            codeEditor.lineNumbers.SetText(lineNumbersText);
         }

         // Function to toggle code folding
         function toggleFold(button) {
            var startLine = button.startLine;
            var text = edtTxt.GetText();
            var lines = text.split("\n");

            if (!button.isFolded) {
                // Find the end of the block to fold
                var endLine = findMatchingEnd(lines, startLine-1);

                if (endLine > startLine) {
                    // Store the folded content
                    var foldedContent = lines.slice(startLine, endLine).join("\n");

                    // Create new text with folded section
                    var newLines = lines.slice(0, startLine);
                    newLines.push("/* ... folded code ... */");
                    newLines = newLines.concat(lines.slice(endLine));

                    // Save fold information
                    var foldInfo = {
                        startLine: startLine,
                        endLine: endLine,
                        content: foldedContent
                    };
                    codeEditor.foldedSections.push(foldInfo);

                    // Update button state
                    button.SetText("[-]");
                    button.isFolded = true;

                    // Update text
                    edtTxt.SetText(newLines.join("\n"));
                }
            } else {
                // Find the fold info for this button
                var foldInfo = null;
                for (var i = 0; i < codeEditor.foldedSections.length; i++) {
                    if (codeEditor.foldedSections[i].startLine === startLine) {
                        foldInfo = codeEditor.foldedSections[i];
                        codeEditor.foldedSections.splice(i, 1);
                        break;
                    }
                }

                if (foldInfo) {
                    // Restore the folded content
                    var newLines = lines.slice(0, startLine);
                    newLines.push(foldInfo.content);
                    newLines = newLines.concat(lines.slice(startLine + 1));

                    // Update button state
                    button.SetText("[+]");
                    button.isFolded = false;

                    // Update text
                    edtTxt.SetText(newLines.join("\n"));
                }
            }
         }

         // Function to find the matching end of a code block
         function findMatchingEnd(lines, startIdx) {
            var line = lines[startIdx].trim();
            var indentLevel = getIndentLevel(lines[startIdx]);

            // For languages with braces
            if (line.endsWith("{")) {
                var braceCount = 1;

                for (var i = startIdx + 1; i < lines.length; i++) {
                    var currLine = lines[i];

                    // Count opening and closing braces
                    for (var j = 0; j < currLine.length; j++) {
                        if (currLine[j] === "{") braceCount++;
                        if (currLine[j] === "}") braceCount--;

                        // Found matching closing brace
                        if (braceCount === 0) return i + 1;
                    }
                }
            }
            // For Python-style indentation
            else if (line.endsWith(":")) {
                for (var i = startIdx + 1; i < lines.length; i++) {
                    // If we find a line with same or less indentation, that's the end
                    if (lines[i].trim().length > 0 && getIndentLevel(lines[i]) <= indentLevel) {
                        return i;
                    }
                }
            }

            // Default to next line if no match found
            return startIdx + 2;
         }

         // Function to get indentation level of a line
         function getIndentLevel(line) {
            var indent = 0;
            for (var i = 0; i < line.length; i++) {
                if (line[i] === ' ') indent++;
                else if (line[i] === '\t') indent += 4;
                else break;
            }
            return indent;
         }

         // Function to handle auto-indentation
         function handleAutoIndent() {
            // Get current cursor position and text
            var cursorPos = edtTxt.GetCursorPos();
            var text = edtTxt.GetText();

            // Check if the user just pressed Enter (added a new line)
            if (cursorPos > 0 && text.charAt(cursorPos - 1) === '\n') {
                // Get the previous line to determine indentation
                var prevLineStart = text.lastIndexOf('\n', cursorPos - 2);
                if (prevLineStart === -1) prevLineStart = 0;
                else prevLineStart++; // Skip the newline character

                var prevLine = text.substring(prevLineStart, cursorPos - 1);

                // Calculate indentation (count leading spaces/tabs)
                var indent = "";
                for (var i = 0; i < prevLine.length; i++) {
                    if (prevLine.charAt(i) === ' ' || prevLine.charAt(i) === '\t') {
                        indent += prevLine.charAt(i);
                    } else {
                        break;
                    }
                }

                // Add extra indentation if the previous line ends with {, :, or (
                var lastChar = prevLine.trim().slice(-1);
                if (lastChar === '{' || lastChar === ':' || lastChar === '(') {
                    indent += '    '; // Add 4 spaces for additional indentation
                }

                // Insert the indentation at the cursor position
                if (indent.length > 0) {
                    edtTxt.InsertText(indent);
                }
            }
         }

         // Add components to layout
         codeEditor.layout.AddChild(codeEditor.leftPanel);
         codeEditor.layout.AddChild(edtTxt);

         // Initialize line numbers
         updateLineNumbers();

         return codeEditor.layout;
      }
} //end.codeEditor

function keybd(shown) {
      keybd.init = function() {
         keybd.width = app.GetScreenWidth()
         keybd.height = app.GetScreenHeight()
         keybd.sizeFactor = 0.00
         if (app.GetOrientation() == "Portrait") {
            keybd.sizeFactor = 0.056;
         }
         if (app.GetOrientation() == "Landscape") {
            keybd.sizeFactor = keybd.sizeFactor
         }
         keybd.sizeAll()
      }
      keybd.sizeAll = function() {
         keybd.widthFinal = keybd.width * codeEditor.w
         keybd.heightFinal = keybd.height * (codeEditor.h + keybd.sizeFactor)
         keybd.heightFinal -= app.GetKeyboardHeight()

         // Resize the entire layout
         layM.codeEdit.SetSize(keybd.widthFinal, keybd.heightFinal, "px");

         // Resize line numbers and editor to maintain proportions
         if (codeEditor.lineNumbers) {
            codeEditor.lineNumbers.SetSize(keybd.widthFinal * 0.1, keybd.heightFinal, "px");
            edtTxt.SetSize(keybd.widthFinal * 0.9, keybd.heightFinal, "px");
         }

         //debug
         /*
         app.ShowPopup( "width" + keybd.widthFinal );
         app.ShowPopup( "height" + keybd.heightFinal );
         app.ShowPopup("factor" + keybd.sizeFactor)
         */
      }
} //end.keybd
//------------------------------------------------------------------------
// Git Integration
//------------------------------------------------------------------------
function gitIntegration() {
    // Initialize Git functionality
    this.init = function() {
        // Create Git panel
        this.createGitPanel();
        
        // Check if Git is installed
        this.checkGitInstallation();
    };
    
    // Check if Git is installed on the device
    this.checkGitInstallation = function() {
        // Use DroidScript's system command to check for Git
        app.SystemCmd("which git", function(result) {
            if (result.trim() === "") {
                app.ShowPopup("Git is not installed. Some features may not work.");
                gitIntegration.isGitInstalled = false;
            } else {
                gitIntegration.isGitInstalled = true;
                gitIntegration.gitPath = result.trim();
                
                // Initialize repository information
                gitIntegration.getCurrentBranch();
            }
        });
    };
    
    // Create Git panel UI
    this.createGitPanel = function() {
        // Create a dialog for Git operations
        gitIntegration.dlgGit = app.CreateDialog("Git Operations");
        
        // Create layout for Git dialog
        gitIntegration.layGit = app.CreateLayout("Linear", "Vertical");
        gitIntegration.layGit.SetSize(0.9, 0.7);
        
        // Create status text
        gitIntegration.txtStatus = app.CreateText("Git Status", 0.9, 0.1);
        gitIntegration.txtStatus.SetTextSize(16);
        gitIntegration.txtStatus.SetMargins(0, 0.01, 0, 0.01);
        
        // Create branch information
        gitIntegration.txtBranch = app.CreateText("Branch: Loading...", 0.9, 0.05);
        gitIntegration.txtBranch.SetTextSize(14);
        gitIntegration.txtBranch.SetMargins(0, 0.01, 0, 0.01);
        
        // Create Git output area
        gitIntegration.txtOutput = app.CreateText("", 0.9, 0.3);
        gitIntegration.txtOutput.SetBackColor("#222222");
        gitIntegration.txtOutput.SetTextColor("#FFFFFF");
        gitIntegration.txtOutput.SetTextSize(12);
        gitIntegration.txtOutput.SetPadding(0.01, 0.01, 0.01, 0.01);
        
        // Create buttons for Git operations
        var layButtons = app.CreateLayout("Linear", "Horizontal,Wrap");
        layButtons.SetSize(0.9, -1);
        
        // Status button
        gitIntegration.btnStatus = app.CreateButton("Status", 0.29, 0.08);
        gitIntegration.btnStatus.SetOnTouch(function() {
            gitIntegration.getStatus();
        });
        layButtons.AddChild(gitIntegration.btnStatus);
        
        // Add button
        gitIntegration.btnAdd = app.CreateButton("Add All", 0.29, 0.08);
        gitIntegration.btnAdd.SetOnTouch(function() {
            gitIntegration.addAll();
        });
        layButtons.AddChild(gitIntegration.btnAdd);
        
        // Commit button
        gitIntegration.btnCommit = app.CreateButton("Commit", 0.29, 0.08);
        gitIntegration.btnCommit.SetOnTouch(function() {
            gitIntegration.commit();
        });
        layButtons.AddChild(gitIntegration.btnCommit);
        
        // Pull button
        gitIntegration.btnPull = app.CreateButton("Pull", 0.29, 0.08);
        gitIntegration.btnPull.SetOnTouch(function() {
            gitIntegration.pull();
        });
        layButtons.AddChild(gitIntegration.btnPull);
        
        // Push button
        gitIntegration.btnPush = app.CreateButton("Push", 0.29, 0.08);
        gitIntegration.btnPush.SetOnTouch(function() {
            gitIntegration.push();
        });
        layButtons.AddChild(gitIntegration.btnPush);
        
        // Log button
        gitIntegration.btnLog = app.CreateButton("Log", 0.29, 0.08);
        gitIntegration.btnLog.SetOnTouch(function() {
            gitIntegration.log();
        });
        layButtons.AddChild(gitIntegration.btnLog);
        
        // Add components to layout
        gitIntegration.layGit.AddChild(gitIntegration.txtBranch);
        gitIntegration.layGit.AddChild(gitIntegration.txtStatus);
        gitIntegration.layGit.AddChild(gitIntegration.txtOutput);
        gitIntegration.layGit.AddChild(layButtons);
        
        // Add layout to dialog
        gitIntegration.dlgGit.AddLayout(gitIntegration.layGit);
    };
    
    // Show Git panel
    this.showGitPanel = function() {
        // Refresh Git status before showing
        this.getStatus();
        
        // Show the dialog
        gitIntegration.dlgGit.Show();
    };
    
    // Get current Git status
    this.getStatus = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git status command
        app.SystemCmd("cd " + workingDir + " && git status", function(result) {
            gitIntegration.txtOutput.SetText(result);
        });
    };
    
    // Get current branch
    this.getCurrentBranch = function() {
        if (!gitIntegration.isGitInstalled) return;
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git branch command
        app.SystemCmd("cd " + workingDir + " && git branch --show-current", function(result) {
            gitIntegration.txtBranch.SetText("Branch: " + result.trim());
            gitIntegration.currentBranch = result.trim();
        });
    };
    
    // Add all files to Git
    this.addAll = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git add command
        app.SystemCmd("cd " + workingDir + " && git add .", function(result) {
            gitIntegration.txtOutput.SetText("Files added to staging area");
            gitIntegration.getStatus();
        });
    };
    
    // Commit changes
    this.commit = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Create commit message dialog
        var dlgCommit = app.CreateDialog("Commit Message");
        var layCommit = app.CreateLayout("Linear", "Vertical");
        
        // Create commit message input
        var edtCommit = app.CreateTextEdit("", 0.8, 0.2);
        edtCommit.SetHint("Enter commit message");
        
        // Create commit button
        var btnDoCommit = app.CreateButton("Commit", 0.8, 0.1);
        btnDoCommit.SetOnTouch(function() {
            var message = edtCommit.GetText();
            if (message.trim() === "") {
                app.ShowPopup("Please enter a commit message");
                return;
            }
            
            // Get current working directory
            var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
            var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
            
            // Execute Git commit command
            app.SystemCmd("cd " + workingDir + " && git commit -m \"" + message + "\"", function(result) {
                gitIntegration.txtOutput.SetText(result);
                dlgCommit.Dismiss();
            });
        });
        
        // Add components to layout
        layCommit.AddChild(edtCommit);
        layCommit.AddChild(btnDoCommit);
        
        // Add layout to dialog and show
        dlgCommit.AddLayout(layCommit);
        dlgCommit.Show();
    };
    
    // Pull changes from remote
    this.pull = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git pull command
        app.SystemCmd("cd " + workingDir + " && git pull", function(result) {
            gitIntegration.txtOutput.SetText(result);
        });
    };
    
    // Push changes to remote
    this.push = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git push command
        app.SystemCmd("cd " + workingDir + " && git push", function(result) {
            gitIntegration.txtOutput.SetText(result);
        });
    };
    
    // Show Git log
    this.log = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git log command
        app.SystemCmd("cd " + workingDir + " && git log --oneline -n 10", function(result) {
            gitIntegration.txtOutput.SetText(result);
        });
    };
}
//------------------------------------------------------------------------
// Cloud Storage Integration
//------------------------------------------------------------------------
function cloudStorage() {
    // Initialize cloud storage functionality
    this.init = function() {
        // Create cloud storage panel
        this.createCloudPanel();
        
        // Load saved cloud settings
        this.loadCloudSettings();
    };
    
    // Load saved cloud settings
    this.loadCloudSettings = function() {
        cloudStorage.isGoogleDriveConnected = app.LoadBoolean("isGDriveConnected", false, "cloudSettings.txt");
        cloudStorage.googleDriveToken = app.LoadText("gDriveToken", "", "cloudSettings.txt");
        
        // Update UI based on connection status
        if (cloudStorage.isGoogleDriveConnected) {
            cloudStorage.btnGDriveConnect.SetText("Disconnect Google Drive");
            cloudStorage.txtStatus.SetText("Connected to Google Drive");
        } else {
            cloudStorage.btnGDriveConnect.SetText("Connect Google Drive");
            cloudStorage.txtStatus.SetText("Not connected to cloud storage");
        }
    };
    
    // Create cloud storage panel UI
    this.createCloudPanel = function() {
        // Create a dialog for cloud storage operations
        cloudStorage.dlgCloud = app.CreateDialog("Cloud Storage");
        
        // Create layout for cloud dialog
        cloudStorage.layCloud = app.CreateLayout("Linear", "Vertical");
        cloudStorage.layCloud.SetSize(0.9, 0.7);
        
        // Create status text
        cloudStorage.txtStatus = app.CreateText("Cloud Storage Status", 0.9, 0.1);
        cloudStorage.txtStatus.SetTextSize(16);
        cloudStorage.txtStatus.SetMargins(0, 0.01, 0, 0.01);
        
        // Create Google Drive connection button
        cloudStorage.btnGDriveConnect = app.CreateButton("Connect Google Drive", 0.8, 0.1);
        cloudStorage.btnGDriveConnect.SetOnTouch(function() {
            if (cloudStorage.isGoogleDriveConnected) {
                // Disconnect from Google Drive
                cloudStorage.disconnectGoogleDrive();
            } else {
                // Connect to Google Drive
                cloudStorage.connectGoogleDrive();
            }
        });
        
        // Create file list
        cloudStorage.lstFiles = app.CreateList("", 0.9, 0.4);
        cloudStorage.lstFiles.SetBackColor("#222222");
        cloudStorage.lstFiles.SetOnTouch(function(title, body) {
            // Download the selected file
            cloudStorage.downloadFile(body);
        });
        
        // Create buttons for cloud operations
        var layButtons = app.CreateLayout("Linear", "Horizontal,Wrap");
        layButtons.SetSize(0.9, -1);
        
        // Upload button
        cloudStorage.btnUpload = app.CreateButton("Upload Current File", 0.44, 0.08);
        cloudStorage.btnUpload.SetOnTouch(function() {
            cloudStorage.uploadCurrentFile();
        });
        layButtons.AddChild(cloudStorage.btnUpload);
        
        // Refresh button
        cloudStorage.btnRefresh = app.CreateButton("Refresh Files", 0.44, 0.08);
        cloudStorage.btnRefresh.SetOnTouch(function() {
            cloudStorage.listFiles();
        });
        layButtons.AddChild(cloudStorage.btnRefresh);
        
        // Add components to layout
        cloudStorage.layCloud.AddChild(cloudStorage.txtStatus);
        cloudStorage.layCloud.AddChild(cloudStorage.btnGDriveConnect);
        cloudStorage.layCloud.AddChild(cloudStorage.lstFiles);
        cloudStorage.layCloud.AddChild(layButtons);
        
        // Add layout to dialog
        cloudStorage.dlgCloud.AddLayout(cloudStorage.layCloud);
    };
    
    // Show cloud storage panel
    this.showCloudPanel = function() {
        // Refresh file list if connected
        if (cloudStorage.isGoogleDriveConnected) {
            this.listFiles();
        }
        
        // Show the dialog
        cloudStorage.dlgCloud.Show();
    };
    
    // Connect to Google Drive
    this.connectGoogleDrive = function() {
        // In a real implementation, this would use OAuth2 to authenticate with Google Drive
        // For this demo, we'll simulate a connection
        
        // Show a simulated authentication dialog
        var dlgAuth = app.CreateDialog("Google Drive Authentication");
        var layAuth = app.CreateLayout("Linear", "Vertical");
        layAuth.SetSize(0.8, 0.4);
        
        var txtInfo = app.CreateText("Enter your Google account credentials:", 0.8, -1);
        txtInfo.SetTextSize(16);
        
        var edtEmail = app.CreateTextEdit("", 0.8, -1, "Email");
        edtEmail.SetHint("Email");
        
        var edtPassword = app.CreateTextEdit("", 0.8, -1, "Password");
        edtPassword.SetHint("Password");
        
        var btnLogin = app.CreateButton("Login", 0.8, -1);
        btnLogin.SetOnTouch(function() {
            // Simulate successful authentication
            var email = edtEmail.GetText();
            if (email.trim() === "") {
                app.ShowPopup("Please enter an email address");
                return;
            }
            
            // Save connection status and token (simulated)
            app.SaveBoolean("isGDriveConnected", true, "cloudSettings.txt");
            app.SaveText("gDriveToken", "simulated_token_" + new Date().getTime(), "cloudSettings.txt");
            
            // Update UI
            cloudStorage.isGoogleDriveConnected = true;
            cloudStorage.googleDriveToken = app.LoadText("gDriveToken", "", "cloudSettings.txt");
            cloudStorage.btnGDriveConnect.SetText("Disconnect Google Drive");
            cloudStorage.txtStatus.SetText("Connected to Google Drive as " + email);
            
            // List files
            cloudStorage.listFiles();
            
            // Close dialog
            dlgAuth.Dismiss();
        });
        
        // Add components to layout
        layAuth.AddChild(txtInfo);
        layAuth.AddChild(edtEmail);
        layAuth.AddChild(edtPassword);
        layAuth.AddChild(btnLogin);
        
        // Add layout to dialog and show
        dlgAuth.AddLayout(layAuth);
        dlgAuth.Show();
    };
    
    // Disconnect from Google Drive
    this.disconnectGoogleDrive = function() {
        // Clear connection status and token
        app.SaveBoolean("isGDriveConnected", false, "cloudSettings.txt");
        app.SaveText("gDriveToken", "", "cloudSettings.txt");
        
        // Update UI
        cloudStorage.isGoogleDriveConnected = false;
        cloudStorage.googleDriveToken = "";
        cloudStorage.btnGDriveConnect.SetText("Connect Google Drive");
        cloudStorage.txtStatus.SetText("Not connected to cloud storage");
        
        // Clear file list
        cloudStorage.lstFiles.RemoveAll();
        
        app.ShowPopup("Disconnected from Google Drive");
    };
    
    // List files from Google Drive
    this.listFiles = function() {
        if (!cloudStorage.isGoogleDriveConnected) {
            app.ShowPopup("Not connected to Google Drive");
            return;
        }
        
        // Clear existing list
        cloudStorage.lstFiles.RemoveAll();
        
        // In a real implementation, this would fetch files from Google Drive API
        // For this demo, we'll simulate some files
        
        // Simulate loading delay
        cloudStorage.txtStatus.SetText("Loading files...");
        
        setTimeout(function() {
            // Add simulated files to the list
            cloudStorage.lstFiles.AddItem("example.js", "example.js");
            cloudStorage.lstFiles.AddItem("notes.txt", "notes.txt");
            cloudStorage.lstFiles.AddItem("project.html", "project.html");
            cloudStorage.lstFiles.AddItem("styles.css", "styles.css");
            cloudStorage.lstFiles.AddItem("app.js", "app.js");
            
            cloudStorage.txtStatus.SetText("Connected to Google Drive");
        }, 1000);
    };
    
    // Upload current file to Google Drive
    this.uploadCurrentFile = function() {
        if (!cloudStorage.isGoogleDriveConnected) {
            app.ShowPopup("Not connected to Google Drive");
            return;
        }
        
        // Get current file
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        if (currentFile === "") {
            app.ShowPopup("No file is currently open");
            return;
        }
        
        // Get file name from path
        var fileName = currentFile.substring(currentFile.lastIndexOf("/") + 1);
        
        // In a real implementation, this would upload the file to Google Drive API
        // For this demo, we'll simulate an upload
        
        cloudStorage.txtStatus.SetText("Uploading " + fileName + "...");
        
        setTimeout(function() {
            // Simulate successful upload
            cloudStorage.txtStatus.SetText("Connected to Google Drive");
            app.ShowPopup(fileName + " uploaded successfully");
            
            // Refresh file list
            cloudStorage.listFiles();
        }, 1500);
    };
    
    // Download file from Google Drive
    this.downloadFile = function(fileName) {
        if (!cloudStorage.isGoogleDriveConnected) {
            app.ShowPopup("Not connected to Google Drive");
            return;
        }
        
        // In a real implementation, this would download the file from Google Drive API
        // For this demo, we'll simulate a download
        
        // Ask for download location
        var dlgDownload = app.CreateDialog("Download Location");
        var layDownload = app.CreateLayout("Linear", "Vertical");
        layDownload.SetSize(0.8, 0.3);
        
        var txtInfo = app.CreateText("Download " + fileName + " to:", 0.8, -1);
        txtInfo.SetTextSize(16);
        
        var edtPath = app.CreateTextEdit(app.GetAppPath() + "/", 0.8, -1);
        
        var btnDownload = app.CreateButton("Download", 0.8, -1);
        btnDownload.SetOnTouch(function() {
            var downloadPath = edtPath.GetText() + fileName;
            
            cloudStorage.txtStatus.SetText("Downloading " + fileName + "...");
            
            setTimeout(function() {
                // Simulate successful download
                cloudStorage.txtStatus.SetText("Connected to Google Drive");
                app.ShowPopup(fileName + " downloaded to " + downloadPath);
                
                // Create a simulated file with sample content
                var content = "// This is a simulated file downloaded from cloud storage\n";
                content += "// Filename: " + fileName + "\n";
                content += "// Downloaded on: " + new Date().toString() + "\n\n";
                
                if (fileName.endsWith(".js")) {
                    content += "function exampleFunction() {\n";
                    content += "    console.log('Hello from cloud storage!');\n";
                    content += "}\n";
                } else if (fileName.endsWith(".html")) {
                    content += "<html>\n<head>\n    <title>Cloud Storage Example</title>\n</head>\n";
                    content += "<body>\n    <h1>Hello from cloud storage!</h1>\n</body>\n</html>\n";
                } else if (fileName.endsWith(".css")) {
                    content += "body {\n    font-family: Arial, sans-serif;\n    background-color: #f0f0f0;\n}\n";
                } else {
                    content += "Sample content for " + fileName + "\n";
                }
                
                // Write the file
                app.WriteFile(downloadPath, content);
                
                // Open the file in the editor
                app.SaveText("currentFile", downloadPath, "currentFile.txt");
                edtTxt.SetText(content);
                
                // Update title bar
                titleBar.SetPath(downloadPath);
                
                // Close dialog
                dlgDownload.Dismiss();
            }, 1500);
        });
        
        // Add components to layout
        layDownload.AddChild(txtInfo);
        layDownload.AddChild(edtPath);
        layDownload.AddChild(btnDownload);
        
        // Add layout to dialog and show
        dlgDownload.AddLayout(layDownload);
        dlgDownload.Show();
    };
}
//------------------------------------------------------------------------
// Terminal/Console Integration
//------------------------------------------------------------------------
function terminalConsole() {
    // Initialize terminal functionality
    this.init = function() {
        // Create terminal panel
        this.createTerminalPanel();
        
        // Initialize command history
        terminalConsole.commandHistory = [];
        terminalConsole.historyIndex = -1;
    };
    
    // Create terminal panel UI
    this.createTerminalPanel = function() {
        // Create a dialog for terminal operations
        terminalConsole.dlgTerminal = app.CreateDialog("Terminal");
        
        // Create layout for terminal dialog
        terminalConsole.layTerminal = app.CreateLayout("Linear", "Vertical");
        terminalConsole.layTerminal.SetSize(0.9, 0.7);
        
        // Create terminal output area
        terminalConsole.txtOutput = app.CreateText("", 0.9, 0.5, "MultiLine,MonoSpace");
        terminalConsole.txtOutput.SetBackColor("#000000");
        terminalConsole.txtOutput.SetTextColor("#00FF00");
        terminalConsole.txtOutput.SetTextSize(12);
        terminalConsole.txtOutput.SetPadding(0.01, 0.01, 0.01, 0.01);
        
        // Add initial welcome message
        terminalConsole.txtOutput.SetText("ProtoEditor Terminal v1.0\n$ ");
        
        // Create command input
        terminalConsole.edtCommand = app.CreateTextEdit("", 0.9, 0.1, "SingleLine");
        terminalConsole.edtCommand.SetHint("Enter command");
        terminalConsole.edtCommand.SetBackColor("#222222");
        terminalConsole.edtCommand.SetTextColor("#FFFFFF");
        
        // Handle command execution on Enter key
        terminalConsole.edtCommand.SetOnEnter(function() {
            terminalConsole.executeCommand();
        });
        
        // Create buttons for terminal operations
        var layButtons = app.CreateLayout("Linear", "Horizontal");
        layButtons.SetSize(0.9, -1);
        
        // Execute button
        terminalConsole.btnExecute = app.CreateButton("Execute", 0.3, 0.08);
        terminalConsole.btnExecute.SetOnTouch(function() {
            terminalConsole.executeCommand();
        });
        layButtons.AddChild(terminalConsole.btnExecute);
        
        // Clear button
        terminalConsole.btnClear = app.CreateButton("Clear", 0.3, 0.08);
        terminalConsole.btnClear.SetOnTouch(function() {
            terminalConsole.txtOutput.SetText("$ ");
        });
        layButtons.AddChild(terminalConsole.btnClear);
        
        // Run Script button
        terminalConsole.btnRunScript = app.CreateButton("Run Script", 0.3, 0.08);
        terminalConsole.btnRunScript.SetOnTouch(function() {
            terminalConsole.runCurrentScript();
        });
        layButtons.AddChild(terminalConsole.btnRunScript);
        
        // Add components to layout
        terminalConsole.layTerminal.AddChild(terminalConsole.txtOutput);
        terminalConsole.layTerminal.AddChild(terminalConsole.edtCommand);
        terminalConsole.layTerminal.AddChild(layButtons);
        
        // Add layout to dialog
        terminalConsole.dlgTerminal.AddLayout(terminalConsole.layTerminal);
    };
    
    // Show terminal panel
    this.showTerminalPanel = function() {
        // Show the dialog
        terminalConsole.dlgTerminal.Show();
        
        // Focus on command input
        terminalConsole.edtCommand.Focus();
    };
    
    // Execute command
    this.executeCommand = function() {
        // Get command
        var command = terminalConsole.edtCommand.GetText().trim();
        if (command === "") return;
        
        // Add command to history
        terminalConsole.commandHistory.push(command);
        terminalConsole.historyIndex = terminalConsole.commandHistory.length;
        
        // Display command in output
        var currentOutput = terminalConsole.txtOutput.GetText();
        terminalConsole.txtOutput.SetText(currentOutput + command + "\n");
        
        // Clear command input
        terminalConsole.edtCommand.SetText("");
        
        // Process command
        if (command.startsWith("cd ")) {
            // Change directory command
            var dir = command.substring(3);
            terminalConsole.appendOutput("Changed directory to: " + dir + "\n$ ");
        } else if (command === "ls" || command === "dir") {
            // List directory command
            var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
            var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
            
            app.SystemCmd("ls -la " + workingDir, function(result) {
                terminalConsole.appendOutput(result + "\n$ ");
            });
        } else if (command === "pwd") {
            // Print working directory command
            var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
            var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
            
            terminalConsole.appendOutput(workingDir + "\n$ ");
        } else if (command === "clear") {
            // Clear terminal command
            terminalConsole.txtOutput.SetText("$ ");
        } else if (command === "help") {
            // Help command
            var helpText = "Available commands:\n";
            helpText += "  cd <dir>     - Change directory\n";
            helpText += "  ls, dir      - List directory contents\n";
            helpText += "  pwd          - Print working directory\n";
            helpText += "  clear        - Clear terminal\n";
            helpText += "  help         - Show this help\n";
            helpText += "  run          - Run current file\n";
            helpText += "  exit         - Close terminal\n";
            
            terminalConsole.appendOutput(helpText + "\n$ ");
        } else if (command === "run") {
            // Run current file command
            terminalConsole.runCurrentScript();
        } else if (command === "exit") {
            // Exit terminal command
            terminalConsole.dlgTerminal.Dismiss();
        } else {
            // Execute system command
            app.SystemCmd(command, function(result) {
                if (result.trim() === "") {
                    result = "Command executed";
                }
                terminalConsole.appendOutput(result + "\n$ ");
            });
        }
    };
    
    // Append text to terminal output
    this.appendOutput = function(text) {
        var currentOutput = terminalConsole.txtOutput.GetText();
        terminalConsole.txtOutput.SetText(currentOutput + text);
        
        // Scroll to bottom
        var scrollHeight = terminalConsole.txtOutput.GetHeight();
        terminalConsole.txtOutput.ScrollTo(0, scrollHeight);
    };
    
    // Run current script
    this.runCurrentScript = function() {
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        if (currentFile === "") {
            terminalConsole.appendOutput("No file is currently open\n$ ");
            return;
        }
        
        var fileName = currentFile.substring(currentFile.lastIndexOf("/") + 1);
        var fileExt = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
        
        terminalConsole.appendOutput("Running " + fileName + "...\n");
        
        if (fileExt === "js") {
            // Run JavaScript file
            try {
                var code = app.ReadFile(currentFile);
                var result = eval(code);
                terminalConsole.appendOutput("Script executed successfully\n");
                if (result !== undefined) {
                    terminalConsole.appendOutput("Result: " + result + "\n");
                }
            } catch (e) {
                terminalConsole.appendOutput("Error: " + e.message + "\n");
            }
        } else if (fileExt === "py") {
            // Run Python file
            app.SystemCmd("python " + currentFile, function(result) {
                terminalConsole.appendOutput(result + "\n$ ");
            });
        } else if (fileExt === "sh") {
            // Run shell script
            app.SystemCmd("sh " + currentFile, function(result) {
                terminalConsole.appendOutput(result + "\n$ ");
            });
        } else {
            terminalConsole.appendOutput("Unsupported file type for execution\n");
        }
        
        terminalConsole.appendOutput("$ ");
    };
}
//------------------------------------------------------------------------
// Performance Optimization
//------------------------------------------------------------------------
function performanceOptimizer() {
    // Initialize performance optimization
    this.init = function() {
        // Set up file cache
        performanceOptimizer.fileCache = {};
        
        // Set up file usage tracking
        performanceOptimizer.fileUsage = {};
        
        // Load saved file usage data
        var savedUsage = app.LoadText("fileUsage", "{}", "performanceSettings.txt");
        try {
            performanceOptimizer.fileUsage = JSON.parse(savedUsage);
        } catch (e) {
            performanceOptimizer.fileUsage = {};
        }
        
        // Configure lazy loading settings
        performanceOptimizer.lazyLoadThreshold = 100000; // 100KB
        performanceOptimizer.lazyLoadChunkSize = 10000; // 10KB
        
        // Configure memory optimization settings
        performanceOptimizer.maxCacheSize = 5000000; // 5MB
        performanceOptimizer.maxCachedFiles = 20;
    };
    
    // Optimize startup performance
    this.optimizeStartup = function() {
        // Preload frequently used files
        this.preloadFrequentFiles();
        
        // Optimize memory usage
        this.optimizeMemory();
    };
    
    // Preload frequently used files
    this.preloadFrequentFiles = function() {
        // Get the most frequently used files
        var files = [];
        for (var file in performanceOptimizer.fileUsage) {
            files.push({
                path: file,
                count: performanceOptimizer.fileUsage[file]
            });
        }
        
        // Sort by usage count (descending)
        files.sort(function(a, b) {
            return b.count - a.count;
        });
        
        // Preload the top 5 most used files
        for (var i = 0; i < Math.min(5, files.length); i++) {
            var filePath = files[i].path;
            
            // Only preload if the file exists
            if (app.FileExists(filePath)) {
                var content = app.ReadFile(filePath);
                performanceOptimizer.cacheFile(filePath, content);
            }
        }
    };
    
    // Track file usage
    this.trackFileUsage = function(filePath) {
        if (!filePath) return;
        
        // Increment usage count
        if (performanceOptimizer.fileUsage[filePath]) {
            performanceOptimizer.fileUsage[filePath]++;
        } else {
            performanceOptimizer.fileUsage[filePath] = 1;
        }
        
        // Save usage data
        app.SaveText("fileUsage", JSON.stringify(performanceOptimizer.fileUsage), "performanceSettings.txt");
    };
    
    // Cache a file
    this.cacheFile = function(filePath, content) {
        // Add to cache
        performanceOptimizer.fileCache[filePath] = {
            content: content,
            timestamp: new Date().getTime()
        };
        
        // Check if cache is too large
        this.trimCache();
    };
    
    // Get a file from cache
    this.getFromCache = function(filePath) {
        var cachedFile = performanceOptimizer.fileCache[filePath];
        if (cachedFile) {
            // Update timestamp to mark as recently used
            cachedFile.timestamp = new Date().getTime();
            return cachedFile.content;
        }
        return null;
    };
    
    // Trim the cache if it gets too large
    this.trimCache = function() {
        // Get all cached files
        var files = [];
        var totalSize = 0;
        
        for (var path in performanceOptimizer.fileCache) {
            var file = performanceOptimizer.fileCache[path];
            var size = file.content.length;
            totalSize += size;
            
            files.push({
                path: path,
                size: size,
                timestamp: file.timestamp
            });
        }
        
        // If we have too many files or the cache is too large, remove the oldest files
        if (files.length > performanceOptimizer.maxCachedFiles || totalSize > performanceOptimizer.maxCacheSize) {
            // Sort by timestamp (oldest first)
            files.sort(function(a, b) {
                return a.timestamp - b.timestamp;
            });
            
            // Remove oldest files until we're under the limits
            while ((files.length > performanceOptimizer.maxCachedFiles || totalSize > performanceOptimizer.maxCacheSize) && files.length > 0) {
                var oldestFile = files.shift();
                totalSize -= oldestFile.size;
                delete performanceOptimizer.fileCache[oldestFile.path];
            }
        }
    };
    
    // Optimize memory usage
    this.optimizeMemory = function() {
        // Clear unused variables
        if (typeof gc !== 'undefined') {
            gc(); // Force garbage collection if available
        }
        
        // Trim the cache
        this.trimCache();
    };
    
    // Optimize file loading
    this.optimizedLoadFile = function(filePath, callback) {
        // Check cache first
        var cachedContent = this.getFromCache(filePath);
        if (cachedContent) {
            app.ShowPopup("Loaded from cache");
            callback(cachedContent);
            return;
        }
        
        // Load file from disk
        var content = app.ReadFile(filePath);
        
        // Cache the file
        this.cacheFile(filePath, content);
        
        // Check if file is large and needs lazy loading
        if (content.length > this.lazyLoadThreshold) {
            app.ShowPopup("Large file detected, using lazy loading");
            this.lazyLoadFile(content, callback);
        } else {
            callback(content);
        }
    };
    
    // Lazy load a large file
    this.lazyLoadFile = function(content, callback) {
        // Initially load just the first chunk
        var initialChunk = content.substring(0, this.lazyLoadChunkSize);
        
        // Set up a loading indicator
        var loadingIndicator = app.CreateText("Loading file...", 0.8, 0.1);
        loadingIndicator.SetTextColor("#FFFFFF");
        loadingIndicator.SetBackColor("#333333");
        loadingIndicator.SetTextSize(16);
        loadingIndicator.SetPosition(0.1, 0.45);
        app.AddLayout(loadingIndicator);
        
        // Call the callback with the initial chunk
        callback(initialChunk);
        
        // Load the rest of the file in chunks
        var currentPosition = this.lazyLoadChunkSize;
        var totalLength = content.length;
        
        var loadNextChunk = function() {
            if (currentPosition < totalLength) {
                var endPosition = Math.min(currentPosition + performanceOptimizer.lazyLoadChunkSize, totalLength);
                var nextChunk = content.substring(currentPosition, endPosition);
                
                // Update the editor with the next chunk
                var currentText = edtTxt.GetText();
                edtTxt.SetText(currentText + nextChunk);
                
                // Update loading indicator
                var progress = Math.round((endPosition / totalLength) * 100);
                loadingIndicator.SetText("Loading file... " + progress + "%");
                
                // Move to next chunk
                currentPosition = endPosition;
                
                // Schedule next chunk load
                setTimeout(loadNextChunk, 10);
            } else {
                // Remove loading indicator when done
                app.RemoveLayout(loadingIndicator);
                app.ShowPopup("File loaded completely");
            }
        };
        
        // Start loading chunks
        setTimeout(loadNextChunk, 100);
    };
}
//------------------------------------------------------------------------
// File Manager
//------------------------------------------------------------------------
function openFile() {
      app.ChooseFile("Choose a file", "\*/\*", onFileChoose)
} //end.openFile

function osr() {
      osr.url = function(txtIn) {
            osr.file = txtIn
               //url check
            var regexUrl = /[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/ig
            var isURL = regexUrl.exec(osr.file)
               //alert(isURL!==null)
            if (isURL) {
               browser.LoadPage(osr.file)
               return true;
            }
         } //osr.url
      osr.status = function(txtIn) {
            osr.file = txtIn
            var regexUrl = /[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/ig
            var isURL = regexUrl.exec(osr.file)
            return isURL;
         } //osr.status
} //end osr

function onFileChoose(file) {
      app.SaveText("currentFile", file, "currentFile.txt");
      titleBar.SetPath(app.LoadText("currentFile", null, "currentFile.txt"));
      drawer.SetPath(app.LoadText("currentFile", null, "currentFile.txt"));
      if ((file.indexOf(".mp3") > -1) | (file.indexOf(".flac") > -1) | (file.indexOf(".wav") > -1) | (file.indexOf(".aac") > -1) | (file.indexOf(".wma") > -1)) {
         var ap = new audioPlayer();
         app.SaveText("currentFile", file, "currentFile.txt");
         listRecents.AddItem(file, 'audio', null);
         app.SaveBoolean("isProtected", true, "isProtected.txt");
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         spnSyntax.SetText("audio");
         ap.CreateAudioPlayer()
         ap.LoadAudio(file);
         ap.Show()
         ap.PlayAudio()
         return
      }
      if ((file.indexOf("mp4") > -1) | (file.indexOf(".mov") > -1) | (file.indexOf(".avi") > -1) | (file.indexOf(".mkv") > -1) | (file.indexOf(".mpeg4") > -1) | (file.indexOf(".3gp") > -1) | (file.indexOf(".webm") > -1)) {
         var vp = new videoPlayer();
         app.SaveText("currentFile", file, "currentFile.txt");
         app.SaveBoolean("isProtected", true, "isProtected.txt");
         listRecents.AddItem(file, 'video', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         spnSyntax.SetText("video");
         vp.CreateVideoPlayer()
         vp.LoadVideo(file);
         vp.PlayVideo();
         return
      }
      if ((file.indexOf(".jpg") > -1) | (file.indexOf(".png") > -1) | (file.indexOf(".jpeg") > -1) | (file.indexOf(".svg") > -1) | (file.indexOf(".psd") > -1) | (file.indexOf(".bmp") > -1) | (file.indexOf(".gif") > -1) | (file.indexOf(".ico") > -1) | (file.indexOf(".cr2") > -1) | (file.indexOf(".raw") > -1)) {
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText("image");
         app.SaveBoolean("isProtected", true, "isProtected.txt");
         webImg = app.CreateWebView(null, null, "IgnoreErrors,NoScrollBars,AllowZoom")
         layImg = app.CreateLayout("frame");
         layImg.AddChild(webImg);
         layTr = app.CreateLayout("linear", "Vertical,Right");
         layImg.AddChild(layTr);
         layTr.SetPadding(null, .18, null, null);
         btnClose = app.CreateButton("[fa-close]", -1, null, "FontAwesome");
         btnShare = app.CreateButton("[fa-share-alt]", -1, null, "FontAwesome");
         btnPrint = app.CreateButton("[fa-print]", -1, null, "FontAwesome");
         layTr.AddChild(btnClose);
         layTr.AddChild(btnShare);
         layTr.AddChild(btnPrint);
         btnPrint.SetOnTouch(function() {
            webImg.Print();
         });
         btnShare.SetOnTouch(function() {
            app.SendFile("file://" + file)
         });
         btnClose.SetOnTouch(function() {
            layM.SetTouchable(true);
            layImg.Gone();
         });
         app.AddLayout(layImg);
         var mdContent2 = '![](' + file + ')';
         var md2 = new mdParser(file, mdContent2);
         var html2 = md2.GetHtml();
         webImg.ClearHistory();
         webImg.LoadHtml(html2);
         layM.SetTouchable(false);
         layImg.Animate("SlideFromBottom");
         spnSyntax.SetText('Syntax');
         listRecents.AddItem(file, "image");
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt");
         return;
      }
      if (file.indexOf(".pdf") > -1) {
         webtmp = app.CreateWebView(1, 1);
         scriptA = app.CreateText(" ");
         scriptA.SetText(app.ReadFile('jsA.txt'));
         scriptB = app.CreateText(" ");
         scriptB.SetText(app.ReadFile('jsB.txt'));
         app.SaveText("currentFile", file, "currentFile.txt");
         listRecents.AddItem(file, '.pdf ', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         spnSyntax.SetText("pdf");
         app.SaveBoolean("isProtected", true, "isProtected.txt");
         app.WriteFile(pathData.GetText() + "/web/viewer.js", scriptA.GetText() + file + scriptB.GetText());
         drawer.webpdf.Hide()
         drawer.webpdf.Show()
         drawer.webpdf.Reload();
         drawer.webpdf.ClearHistory();
         drawer.webpdf.LoadUrl("file:///" + pathData.GetText() + "/web/viewer.html");
         app.OpenDrawer("left");
         drawer.tabs.ShowTab(" PDF Viewer")
         app.OpenDrawer("left");
         return;
      }
      if (file.indexOf(".py") > -1) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText('python');
         listRecents.AddItem(file, ".py", null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return
      }
      if (file.indexOf(".php") > -1) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText('php');
         listRecents.AddItem(file, '.php', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      }
      if ((file.indexOf(".txt") > -1) | (file.indexOf(".text") > -1) | (file.indexOf(".dat") > -1)) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText('text');
         listRecents.AddItem(file, '.txt', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      }
      if (file.indexOf(".js") > -1) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText('javascript');
         listRecents.AddItem(file, '.js', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      }
      if (file.indexOf(".rb") > -1) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText('ruby');
         listRecents.AddItem(file, '.rb', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      }
      if (file.indexOf(".c") > -1) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText(".c");
         listRecents.AddItem(file, '.c', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      }
      if (file.indexOf(".h") > -1) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText(".c");
         listRecents.AddItem(file, '.h', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt");
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      }
      if (file.indexOf(".ino") > -1) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText(".c");
         listRecents.AddItem(file, '.ino', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      }
      if (file.indexOf(".pde") > -1) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText('.java');
         listRecents.AddItem(file, '.pde', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      }
      if (file.indexOf(".md") > -1) {
         if (isEdtA == true) {
            edtA.SetText(app.ReadFile(file));
            return;
         }
         if (isEdtB == true) {
            edtB.SetText(app.ReadFile(file));
            return;
         }
         // Use optimized file loading
         optimizer.trackFileUsage(file);
         optimizer.optimizedLoadFile(file, function(content) {
            edtTxt.SetText(content);
         });
         app.SaveText("currentFile", file, "currentFile.txt");
         spnSyntax.SetText('markdown');
         listRecents.AddItem(file, '.md', null);
         app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      } else {
         dlgOpen = app.CreateDialog("Open File", "NoDim");
         optA = app.CreateButton("Open With ...");
         optA.SetOnTouch(function() {
            var file = app.LoadText("currentFile", null, "currentFile.txt");
            listRecents.AddItem(file, 'other');
            app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
            app.OpenFile(file, "*/*");
            app.SaveText("currentFile", "", "currentFile.txt");
         });
         optB = app.CreateButton("Open");
         optB.SetOnTouch(function() {
            var file = app.LoadText("currentFile", null, "currentFile.txt");
            
            // Use optimized file loading
            optimizer.trackFileUsage(file);
            optimizer.optimizedLoadFile(file, function(content) {
                edtTxt.SetText(content);
            });
            
            app.SaveText("currentFile", file, "currentFile.txt");
            spnSyntax.SetText('Syntax');
            listRecents.AddItem(file, "other");
            app.SaveText("listRecents", listRecents.GetList(","), "listRecents.txt")
            dlgOpen.Hide();
         });
         layDlgOpen = app.CreateLayout("Linear", "VCenter");
         layDlgOpen.AddChild(optA);
         layDlgOpen.AddChild(optB);
         dlgOpen.AddLayout(layDlgOpen);
         dlgOpen.Show();
         app.SaveBoolean("isProtected", false, "isProtected.txt");
         return;
      }
} //end.onFileChoose

//------------------------------------------------------------------------
// Hardware shortcuts
//------------------------------------------------------------------------
function hwShorts() {
   app.SetOnKey(function(action, name) {
      /*debug*/ //app.ShowPopup( action + " " + name );
      if (name == "VOLUME_DOWN" && action == "Down") {
         edtTxt.SetCursorPos(edtTxt.GetCursorPos() - 1)
      }
      if (name == "VOLUME_UP" && action == "Down") {
         edtTxt.SetCursorPos(edtTxt.GetCursorPos() + 1)
      }
   });
}

//------------------------------------------------------------------------
// Event handlers
//------------------------------------------------------------------------
function OnConfig() {
   if (app.LoadBoolean( "isConfig",null, "isConfig.txt" ))
   {
      app.CloseDrawer("left");
      app.CloseDrawer("right");
      app.RemoveDrawer("right");
      app.RemoveDrawer("left")
      drawer.webpdf.LoadUrl("web/viewer.html");
      drawer.buildRight()
      dlgRecents.Dismiss();
      txtUpdate.SetText("Reconfiguring layout...")
      dlgpp.Show()
      app.DestroyLayout(layM);
      build()
      layM.SetTouchable(true);
      layImg.Gone();
      onFileChoose(app.LoadText("currentFile", "/", "currentFile.txt"))
      spnSyntax.SetText(app.LoadText("syntaxTmp", null, "syntaxTmp.txt"))
      dlgpp.Dismiss();
   }
   else
   {
      dlgRecents.Dismiss();
      app.CloseDrawer("left");
      app.CloseDrawer("right");
      app.RemoveDrawer("right");
      app.RemoveDrawer("left")
      var urlLeft = drawer.webpdf.LoadUrl("web/viewer.html");
      drawer.buildLeft(urlLeft)
      drawer.buildRight()
   }
} //end.OnConfig

function OnPause() {
   app.SaveBoolean("oldConfig", app.LoadBoolean("isConfig", null, "isConfig.txt"), "oldConfig.txt");
   app.SaveBoolean("isConfig", false,"isConfig.txt");
   app.SaveText("listRecents", (listRecents.GetList(",") || ","), "listRecents.txt");
} //end.OnPause

function OnResume() {
   app.SaveBoolean("isConfig", app.LoadBoolean("oldConfig", null, "oldConfig.txt"), "isConfig.txt");
} //end.OnResume

function OnData(isStartUp) {
   new osr();
   sharedFiles = app.GetSharedFiles();
   sharedData = app.GetSharedText([0]);
   if (sharedData) {
      if (osr.status(sharedData)) browser.build();
      osr.url(sharedData);
      if (!osr.status(sharedData)) edtTxt.InsertText(sharedData)
   }
   if (sharedFiles) {
      //Display intent data.
      var intent = app.GetIntent();
      if (intent) {
         var s = "";
         s = sharedFiles[0];
         for (var key in intent.extras) {
            if (key = "real_path") {
               s = intent.extras[key];
            }//endif
         }//endfor
         s = s.replace("/storage/emulated/0", "/sdcard");
         onFileChoose(s)
      } //endif
   } //endif
} //end.OnData
