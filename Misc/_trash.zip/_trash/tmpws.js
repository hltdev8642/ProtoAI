function OnStart() {
 //  alert(loadbools("test"))
   //savebools("test2", true);
  // alert(loadbools("test3"))
  btn = app.CreateButton("generate",1,-1);
  btn.SetOnTouch(function ()
  {
    if (loadbools("pressed"))
    {
       alert("true")
        savebools("pressed", false);
    }
    else
    {
      alert("false")
      savebools("pressed", true);
    }
  })
  lay = app.CreateLayout("linear", "vertical,fillxy");
  lay.AddChild(btn);
  app.AddLayout(lay);
  
}

function loadbools(name, dflt) {
   loadbools.dflt = dflt || -1;
   loadbools.name = name | -1;
   /*
   if (loadbools.name <= -1) {
      return false
   } else {
   */
      return app.LoadBoolean(name, dflt, name);
   //}
}

function savebools(name, val, dflt) 
{
   savebools.dflt = dflt || -1;
   savebools.name = name | -1;
 /*
   if (savebools.name <= -1) 
   {
      return false
   }
   else 
   {
   */
      app.SaveBoolean(name, val, name );
      return app.LoadBoolean(name, null, name)
 //  }
}