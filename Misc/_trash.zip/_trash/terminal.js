//------------------------------------------------------------------------
//terminal.js 
//------------------------------------------------------------------------

// Terminal/Console module for ProtoEditor
function terminalConsole() {
    // Initialize terminal functionality
    this.init = function() {
        // Create terminal panel
        this.createTerminalPanel();
        
        // Initialize command history
        this.commandHistory = [];
        this.historyIndex = -1;
    };
    
    // Create terminal panel UI
    this.createTerminalPanel = function() {
        // Create a dialog for terminal operations
        terminalConsole.dlgTerminal = app.CreateDialog("Terminal");
        
        // Create layout for terminal dialog
        terminalConsole.layTerminal = app.CreateLayout("Linear", "Vertical");
        terminalConsole.layTerminal.SetSize(0.9, 0.7);
        
        // Create terminal output area
        terminalConsole.txtOutput = app.CreateText("", 0.9, 0.5);
        terminalConsole.txtOutput.SetBackColor("#000000");
        terminalConsole.txtOutput.SetTextColor("#00FF00");
        terminalConsole.txtOutput.SetTextSize(14);
        terminalConsole.txtOutput.SetPadding(0.01, 0.01, 0.01, 0.01);
        
        // Create command input
        terminalConsole.edtCommand = app.CreateTextEdit("", 0.9, 0.1, "SingleLine");
        terminalConsole.edtCommand.SetHint("Enter command...");
        terminalConsole.edtCommand.SetBackColor("#222222");
        terminalConsole.edtCommand.SetTextColor("#FFFFFF");
        
        // Set up command execution on Enter key
        terminalConsole.edtCommand.SetOnEnter(function() {
            terminalConsole.executeCommand(terminalConsole.edtCommand.GetText());
            terminalConsole.edtCommand.SetText("");
        });
        
        // Create buttons for terminal operations
        var layButtons = app.CreateLayout("Linear", "Horizontal,Wrap");
        layButtons.SetSize(0.9, -1);
        
        // Clear button
        terminalConsole.btnClear = app.CreateButton("Clear", 0.29, 0.08);
        terminalConsole.btnClear.SetOnTouch(function() {
            terminalConsole.txtOutput.SetText("");
        });
        layButtons.AddChild(terminalConsole.btnClear);
        
        // Run Script button
        terminalConsole.btnRunScript = app.CreateButton("Run Script", 0.29, 0.08);
        terminalConsole.btnRunScript.SetOnTouch(function() {
            terminalConsole.runCurrentScript();
        });
        layButtons.AddChild(terminalConsole.btnRunScript);
        
        // Stop button
        terminalConsole.btnStop = app.CreateButton("Stop", 0.29, 0.08);
        terminalConsole.btnStop.SetOnTouch(function() {
            terminalConsole.stopExecution();
        });
        layButtons.AddChild(terminalConsole.btnStop);
        
        // Add components to layout
        terminalConsole.layTerminal.AddChild(terminalConsole.txtOutput);
        terminalConsole.layTerminal.AddChild(terminalConsole.edtCommand);
        terminalConsole.layTerminal.AddChild(layButtons);
        
        // Add layout to dialog
        terminalConsole.dlgTerminal.AddLayout(terminalConsole.layTerminal);
    };
    
    // Show terminal panel
    this.showTerminalPanel = function() {
        // Show the dialog
        terminalConsole.dlgTerminal.Show();
    };
    
    // Execute a command
    this.executeCommand = function(command) {
        if (command.trim() === "") return;
        
        // Add command to history
        terminalConsole.commandHistory.push(command);
        terminalConsole.historyIndex = terminalConsole.commandHistory.length;
        
        // Display command in output
        terminalConsole.appendOutput("> " + command);
        
        // Handle special commands
        if (command.startsWith("cd ")) {
            // Change directory
            var dir = command.substring(3).trim();
            terminalConsole.appendOutput("Changing directory to: " + dir);
            return;
        } else if (command === "clear") {
            // Clear terminal
            terminalConsole.txtOutput.SetText("");
            return;
        } else if (command === "help") {
            // Show help
            terminalConsole.appendOutput("Available commands:");
            terminalConsole.appendOutput("  clear - Clear terminal output");
            terminalConsole.appendOutput("  cd <dir> - Change directory");
            terminalConsole.appendOutput("  run - Run current script");
            terminalConsole.appendOutput("  help - Show this help");
            return;
        } else if (command === "run") {
            // Run current script
            terminalConsole.runCurrentScript();
            return;
        }
        
        // Execute system command
        terminalConsole.appendOutput("Executing: " + command);
        
        // Use DroidScript's system command
        app.SystemCmd(command, function(result) {
            terminalConsole.appendOutput(result);
        });
    };
    
    // Append text to terminal output
    this.appendOutput = function(text) {
        var currentOutput = terminalConsole.txtOutput.GetText();
        terminalConsole.txtOutput.SetText(currentOutput + text + "\n");
        
        // Scroll to bottom
        var scrollHeight = terminalConsole.txtOutput.GetHeight();
        terminalConsole.txtOutput.ScrollTo(0, scrollHeight);
    };
    
    // Run the current script
    this.runCurrentScript = function() {
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        if (currentFile === "") {
            terminalConsole.appendOutput("Error: No file is currently open");
            return;
        }
        
        var fileName = currentFile.substring(currentFile.lastIndexOf("/") + 1);
        var fileExt = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
        
        terminalConsole.appendOutput("Running: " + fileName);
        
        // Handle different file types
        if (fileExt === "js") {
            // JavaScript file
            try {
                var code = edtTxt.GetText();
                var result = eval(code);
                terminalConsole.appendOutput("Result: " + result);
            } catch (e) {
                terminalConsole.appendOutput("Error: " + e.message);
            }
        } else if (fileExt === "html") {
            // HTML file
            terminalConsole.appendOutput("Opening HTML file in browser");
            web.LoadHtml(edtTxt.GetText());
            webd.Show();
        } else if (fileExt === "py") {
            // Python file
            terminalConsole.appendOutput("Python execution not implemented in this demo");
        } else {
            terminalConsole.appendOutput("Unsupported file type: " + fileExt);
        }
    };
    
    // Stop current execution
    this.stopExecution = function() {
        terminalConsole.appendOutput("Execution stopped");
    };
    
    // Navigate command history
    this.navigateHistory = function(direction) {
        if (terminalConsole.commandHistory.length === 0) return;
        
        if (direction === "up") {
            // Go back in history
            if (terminalConsole.historyIndex > 0) {
                terminalConsole.historyIndex--;
                terminalConsole.edtCommand.SetText(terminalConsole.commandHistory[terminalConsole.historyIndex]);
            }
        } else if (direction === "down") {
            // Go forward in history
            if (terminalConsole.historyIndex < terminalConsole.commandHistory.length - 1) {
                terminalConsole.historyIndex++;
                terminalConsole.edtCommand.SetText(terminalConsole.commandHistory[terminalConsole.historyIndex]);
            } else {
                // Clear if at end of history
                terminalConsole.historyIndex = terminalConsole.commandHistory.length;
                terminalConsole.edtCommand.SetText("");
            }
        }
    };
}
