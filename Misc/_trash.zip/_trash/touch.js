//------------------------------------------------------------------------
//Touch.js
//------------------------------------------------------------------------

// Variable to track fullscreen mode state
var isFullscreenMode = false;

function keys_OnTouch() {
      switch (this.icon) {
         case "[fa-undo]":
            edtTxt.Undo();
            break;
         case "[fa-close]":
            edtTxt.SetText(" ");
            break;
         case "[fa-copy]":
            edtTxt.Copy()
            break;
         case "[fa-paste]":
            edtTxt.Paste();
            break;
         case "[fa-arrows-alt]":
            edtTxt.SelectAll();
            break;
         case "[fa-play]":
            var syntax = spnSyntax.GetText();
            app.SaveBoolean("isDebug", false);
            run(syntax);
            break;
         case "[fa-lock]":
            if (!app.LoadBoolean("isLocked", false, "isLocked.txt")) {
               app.SaveBoolean("isLocked", true, "isLocked.txt");
               app.SaveBoolean("isConfig", false, "isConfig.txt");
               app.SetOrientation(app.GetOrientation());
               app.ShowPopup("🔐");
            } else {
               app.SaveBoolean("isLocked", false, "isLocked.txt");
               app.SaveBoolean("isConfig", true, "isConfig.txt");
               app.SetOrientation(app.GetOrientation());
               app.ShowPopup("🔓");
            }
            break;
         case "[fa-share-alt]":
            app.SendText(edtTxt.GetText());
            break;
         case "[fa-bars]":
            app.OpenDrawer("left");
            break;
         case "[fa-folder-open]":
            var oldFile = app.LoadText("currentFile", null, "currentFile.txt");
            app.SaveText("lastFile", oldFile, "lastFile.txt");
            openFile()
            app.CloseDrawer("left");
            break;
         case "[fa-bug]":
            var syntax = spnSyntax.GetText();
            app.SaveBoolean("isDebug", true);
            run(syntax);
            break;
         case "[fa-chrome]":
            var file = app.LoadText("currentFile", null, "currentFile.txt");
            if (file.indexOf(".html") > -1) {
               web.LoadUrl("file://" + file);
               webd.Show();
            } else {
               app.OpenUrl("http://www.google.com");
            }
            break;
         // Theme toggle functionality
         case "[fa-adjust]":
            toggleTheme();
            break;
         // Toggle fullscreen mode
         case "[fa-expand]":
            toggleFullscreenMode();
            break;

         // Open Git panel
         case "[fa-git]":
            git.showGitPanel();
            break;

         // Open Cloud Storage panel
         case "[fa-cloud]":
            cloud.showCloudPanel();
            break;

         // Open Terminal panel
         case "[fa-terminal]":
            terminal.showTerminalPanel();
            break;
      } //end.switch
   } //end.keys_OnTouch

// Function to toggle fullscreen mode
function toggleFullscreenMode() {
    isFullscreenMode = !isFullscreenMode;

    if (isFullscreenMode) {
        // Hide UI elements for fullscreen mode
        titleB.SetVisibility("Gone");
        layM.edtBarA.SetVisibility("Gone");
        layM.edtBarB.SetVisibility("Gone");
        keybar.GetExtraKeyBar(edtTxt).SetVisibility("Gone");

        // Resize editor to take full screen
        var newHeight = parseFloat(1 - 0.045); // Leave a small area for the exit button
        layM.codeEdit.SetSize(1, newHeight);

        // Create a small exit fullscreen button
        if (!window.exitFullscreenBtn) {
            window.exitFullscreenBtn = app.CreateButton("[fa-compress]", 0.15, 0.045, "FontAwesome");
            window.exitFullscreenBtn.SetPosition(0.85, 0);
            window.exitFullscreenBtn.SetOnTouch(toggleFullscreenMode);
            app.AddLayout(window.exitFullscreenBtn);
        } else {
            window.exitFullscreenBtn.SetVisibility("Show");
        }

        app.ShowPopup("Fullscreen mode enabled");
    } else {
        // Restore UI elements
        titleB.SetVisibility("Show");
        layM.edtBarA.SetVisibility("Show");
        layM.edtBarB.SetVisibility("Show");
        keybar.GetExtraKeyBar(edtTxt).SetVisibility("Show");

        // Restore original size
        var originalHeight = parseFloat(1 - (barAHeight + barBHeight + titleBarHeight + keyBarHeight + 0.045));
        layM.codeEdit.SetSize(1, originalHeight);

        // Hide exit button
        if (window.exitFullscreenBtn) {
            window.exitFullscreenBtn.SetVisibility("Gone");
        }

        app.ShowPopup("Fullscreen mode disabled");
    }
}

function keys_OnLTouch() {
      switch (this.icon) {
         case "[fa-save]":
            if (!(app.LoadBoolean("isProtected", false, "isProtected.txt"))) {
               var file = app.LoadText("currentFile", null, "currentFile.txt");
               app.WriteFile(file, app.ReadFile(file));
               app.WriteFile(file, edtTxt.GetText());
               app.ShowPopup("Saved:" + " \n" + file);
            }
            break;
         case "[fa-play]":
            app.SaveBoolean("isDebug", false);
            run("quicksand")
            break;
         case "[fa-exchange]":
            edtTxt.ReplaceAll(searchF.GetText(), searchR.GetText());
            break
            return;
      } //end.switch
   } //end.keys_OnLTouch
