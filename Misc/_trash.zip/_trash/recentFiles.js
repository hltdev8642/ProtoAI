//------------------------------------------------------------------------
//recentFiles.js 
//------------------------------------------------------------------------

// Function to show a popup with recent files for quick access
function showRecentFilesPopup() {
    // Create a dialog for recent files
    var dlgRecentFiles = app.CreateDialog("Recent Files", "NoCancel");
    
    // Create a layout for the dialog
    var layRecent = app.CreateLayout("Linear", "Vertical");
    layRecent.SetSize(0.9, 0.6);
    
    // Get the list of recent files
    var recentFilesList = app.LoadText("listRecents", "", "listRecents.txt");
    var recentFiles = recentFilesList.split(",");
    
    // Create a list to display recent files
    var lstRecent = app.CreateList("", 0.9, 0.5);
    
    // Filter out empty entries and add to list
    for (var i = 0; i < recentFiles.length; i++) {
        if (recentFiles[i] && recentFiles[i].trim() !== "") {
            // Extract filename from path
            var fileName = recentFiles[i].substring(recentFiles[i].lastIndexOf("/") + 1);
            
            // Add file to list with full path as data
            lstRecent.AddItem(fileName, recentFiles[i]);
        }
    }
    
    // Set what happens when a file is selected
    lstRecent.SetOnTouch(function(title, body, type, index) {
        // body contains the full path
        onFileChoose(body);
        dlgRecentFiles.Dismiss();
    });
    
    // Add a search box for filtering files
    var edtSearch = app.CreateTextEdit("", 0.9, -1, "SingleLine");
    edtSearch.SetHint("Search files...");
    
    // Add search functionality
    edtSearch.SetOnChange(function() {
        var searchText = edtSearch.GetText().toLowerCase();
        
        // Clear the list
        lstRecent.RemoveAll();
        
        // Add matching files
        for (var i = 0; i < recentFiles.length; i++) {
            if (recentFiles[i] && recentFiles[i].trim() !== "") {
                var fileName = recentFiles[i].substring(recentFiles[i].lastIndexOf("/") + 1);
                
                // Check if the file name contains the search text
                if (fileName.toLowerCase().indexOf(searchText) !== -1) {
                    lstRecent.AddItem(fileName, recentFiles[i]);
                }
            }
        }
    });
    
    // Add a button to clear the recent files list
    var btnClear = app.CreateButton("Clear Recent Files", 0.9, -1);
    btnClear.SetOnTouch(function() {
        app.SaveText("listRecents", "", "listRecents.txt");
        lstRecent.RemoveAll();
        app.ShowPopup("Recent files list cleared");
    });
    
    // Add components to layout
    layRecent.AddChild(edtSearch);
    layRecent.AddChild(lstRecent);
    layRecent.AddChild(btnClear);
    
    // Add layout to dialog and show it
    dlgRecentFiles.AddLayout(layRecent);
    dlgRecentFiles.Show();
}
