//------------------------------------------------------------------------
//performance.js 
//------------------------------------------------------------------------

// Performance optimization module for ProtoEditor
function performanceOptimizer() {
    // Initialize performance optimization
    this.init = function() {
        // Set up file cache
        this.fileCache = {};
        this.maxCacheSize = 10; // Maximum number of files to cache
        
        // Set up lazy loading for large files
        this.lazyLoadThreshold = 100000; // Characters threshold for lazy loading
        this.lazyLoadChunkSize = 10000; // Characters to load at once
        
        // Initialize performance monitoring
        this.lastRenderTime = 0;
        this.renderCount = 0;
        this.totalRenderTime = 0;
    };
    
    // Cache a file
    this.cacheFile = function(filePath, content) {
        // Check if cache is full
        if (Object.keys(this.fileCache).length >= this.maxCacheSize) {
            // Remove oldest entry
            var oldestTime = Date.now();
            var oldestKey = null;
            
            for (var key in this.fileCache) {
                if (this.fileCache[key].timestamp < oldestTime) {
                    oldestTime = this.fileCache[key].timestamp;
                    oldestKey = key;
                }
            }
            
            if (oldestKey) {
                delete this.fileCache[oldestKey];
            }
        }
        
        // Add file to cache
        this.fileCache[filePath] = {
            content: content,
            timestamp: Date.now()
        };
    };
    
    // Get a file from cache
    this.getFromCache = function(filePath) {
        if (this.fileCache[filePath]) {
            // Update timestamp to mark as recently used
            this.fileCache[filePath].timestamp = Date.now();
            return this.fileCache[filePath].content;
        }
        
        return null;
    };
    
    // Optimize file loading
    this.optimizedLoadFile = function(filePath, callback) {
        // Check cache first
        var cachedContent = this.getFromCache(filePath);
        if (cachedContent) {
            app.ShowPopup("Loaded from cache");
            callback(cachedContent);
            return;
        }
        
        // Load file from disk
        var content = app.ReadFile(filePath);
        
        // Cache the file
        this.cacheFile(filePath, content);
        
        // Check if file is large and needs lazy loading
        if (content.length > this.lazyLoadThreshold) {
            app.ShowPopup("Large file detected, using lazy loading");
            this.lazyLoadFile(content, callback);
        } else {
            callback(content);
        }
    };
    
    // Lazy load a large file
    this.lazyLoadFile = function(content, callback) {
        // Initially load just the first chunk
        var initialChunk = content.substring(0, this.lazyLoadChunkSize);
        
        // Set up a loading indicator
        var loadingIndicator = app.CreateText("Loading file...", 0.8, 0.1);
        loadingIndicator.SetTextColor("#FFFFFF");
        loadingIndicator.SetBackColor("#333333");
        loadingIndicator.SetTextSize(16);
        loadingIndicator.SetPosition(0.1, 0.45);
        app.AddLayout(loadingIndicator);
        
        // Call the callback with the initial chunk
        callback(initialChunk);
        
        // Load the rest of the file in chunks
        var currentPosition = this.lazyLoadChunkSize;
        var totalLength = content.length;
        
        var loadNextChunk = function() {
            if (currentPosition < totalLength) {
                var endPosition = Math.min(currentPosition + performanceOptimizer.lazyLoadChunkSize, totalLength);
                var nextChunk = content.substring(currentPosition, endPosition);
                
                // Update the editor with the next chunk
                var currentText = edtTxt.GetText();
                edtTxt.SetText(currentText + nextChunk);
                
                // Update loading indicator
                var progress = Math.round((endPosition / totalLength) * 100);
                loadingIndicator.SetText("Loading file... " + progress + "%");
                
                // Move to next chunk
                currentPosition = endPosition;
                
                // Schedule next chunk load
                setTimeout(loadNextChunk, 10);
            } else {
                // Remove loading indicator when done
                app.RemoveLayout(loadingIndicator);
                app.ShowPopup("File loaded completely");
            }
        };
        
        // Start loading chunks
        setTimeout(loadNextChunk, 100);
    };
    
    // Start performance monitoring for rendering
    this.startRenderMonitoring = function() {
        this.lastRenderTime = Date.now();
    };
    
    // End performance monitoring for rendering
    this.endRenderMonitoring = function() {
        var renderTime = Date.now() - this.lastRenderTime;
        this.renderCount++;
        this.totalRenderTime += renderTime;
        
        // Log performance data
        console.log("Render time: " + renderTime + "ms");
        console.log("Average render time: " + (this.totalRenderTime / this.renderCount) + "ms");
        
        // If rendering is slow, apply optimizations
        if (renderTime > 500) {
            this.applyRenderOptimizations();
        }
    };
    
    // Apply optimizations for slow rendering
    this.applyRenderOptimizations = function() {
        // Reduce syntax highlighting complexity
        if (typeof edtTxt !== 'undefined') {
            // Temporarily disable syntax highlighting for very large files
            if (edtTxt.GetText().length > 50000) {
                app.ShowPopup("Optimizing editor for large file");
                edtTxt.SetColorScheme("None");
                
                // Re-enable after editing stops
                if (this.syntaxTimer) clearTimeout(this.syntaxTimer);
                this.syntaxTimer = setTimeout(function() {
                    edtTxt.SetColorScheme(app.LoadText("colorScheme", "Dark", "colorScheme.txt"));
                }, 5000);
            }
        }
    };
    
    // Optimize memory usage
    this.optimizeMemory = function() {
        // Clear unused caches
        if (Object.keys(this.fileCache).length > 5) {
            // Keep only the 5 most recent files
            var files = [];
            
            for (var key in this.fileCache) {
                files.push({
                    path: key,
                    timestamp: this.fileCache[key].timestamp
                });
            }
            
            // Sort by timestamp (newest first)
            files.sort(function(a, b) {
                return b.timestamp - a.timestamp;
            });
            
            // Keep only the first 5
            var newCache = {};
            for (var i = 0; i < Math.min(5, files.length); i++) {
                var path = files[i].path;
                newCache[path] = this.fileCache[path];
            }
            
            this.fileCache = newCache;
        }
        
        // Force garbage collection (if available)
        if (typeof global !== 'undefined' && global.gc) {
            global.gc();
        }
    };
    
    // Optimize startup time
    this.optimizeStartup = function() {
        // Load frequently used files in background
        var frequentFiles = app.LoadText("frequentFiles", "", "frequentFiles.txt").split(",");
        
        for (var i = 0; i < frequentFiles.length; i++) {
            if (frequentFiles[i] && frequentFiles[i].trim() !== "") {
                // Load in background
                (function(filePath) {
                    setTimeout(function() {
                        app.ReadFile(filePath, function(content) {
                            performanceOptimizer.cacheFile(filePath, content);
                        });
                    }, i * 1000); // Stagger loading to avoid blocking UI
                })(frequentFiles[i]);
            }
        }
    };
    
    // Track frequently used files
    this.trackFileUsage = function(filePath) {
        if (!filePath) return;
        
        // Load existing frequent files
        var frequentFiles = app.LoadText("frequentFiles", "", "frequentFiles.txt").split(",");
        
        // Check if file is already in the list
        var fileIndex = frequentFiles.indexOf(filePath);
        
        if (fileIndex !== -1) {
            // Remove from current position
            frequentFiles.splice(fileIndex, 1);
        }
        
        // Add to beginning of list (most recent)
        frequentFiles.unshift(filePath);
        
        // Keep only the top 10
        if (frequentFiles.length > 10) {
            frequentFiles = frequentFiles.slice(0, 10);
        }
        
        // Save updated list
        app.SaveText("frequentFiles", frequentFiles.join(","), "frequentFiles.txt");
    };
}
