//------------------------------------------------------------------------
//gitIntegration.js 
//------------------------------------------------------------------------

// Git integration module for ProtoEditor
function gitIntegration() {
    // Initialize Git functionality
    this.init = function() {
        // Create Git panel
        this.createGitPanel();
        
        // Check if Git is installed
        this.checkGitInstallation();
    };
    
    // Check if Git is installed on the device
    this.checkGitInstallation = function() {
        // Use DroidScript's system command to check for Git
        app.SystemCmd("which git", function(result) {
            if (result.trim() === "") {
                app.ShowPopup("Git is not installed. Some features may not work.");
                gitIntegration.isGitInstalled = false;
            } else {
                gitIntegration.isGitInstalled = true;
                gitIntegration.gitPath = result.trim();
                
                // Initialize repository information
                gitIntegration.getCurrentBranch();
            }
        });
    };
    
    // Create Git panel UI
    this.createGitPanel = function() {
        // Create a dialog for Git operations
        gitIntegration.dlgGit = app.CreateDialog("Git Operations");
        
        // Create layout for Git dialog
        gitIntegration.layGit = app.CreateLayout("Linear", "Vertical");
        gitIntegration.layGit.SetSize(0.9, 0.7);
        
        // Create status text
        gitIntegration.txtStatus = app.CreateText("Git Status", 0.9, 0.1);
        gitIntegration.txtStatus.SetTextSize(16);
        gitIntegration.txtStatus.SetMargins(0, 0.01, 0, 0.01);
        
        // Create branch information
        gitIntegration.txtBranch = app.CreateText("Branch: Loading...", 0.9, 0.05);
        gitIntegration.txtBranch.SetTextSize(14);
        gitIntegration.txtBranch.SetMargins(0, 0.01, 0, 0.01);
        
        // Create Git output area
        gitIntegration.txtOutput = app.CreateText("", 0.9, 0.3);
        gitIntegration.txtOutput.SetBackColor("#222222");
        gitIntegration.txtOutput.SetTextColor("#FFFFFF");
        gitIntegration.txtOutput.SetTextSize(12);
        gitIntegration.txtOutput.SetPadding(0.01, 0.01, 0.01, 0.01);
        
        // Create buttons for Git operations
        var layButtons = app.CreateLayout("Linear", "Horizontal,Wrap");
        layButtons.SetSize(0.9, -1);
        
        // Status button
        gitIntegration.btnStatus = app.CreateButton("Status", 0.29, 0.08);
        gitIntegration.btnStatus.SetOnTouch(function() {
            gitIntegration.getStatus();
        });
        layButtons.AddChild(gitIntegration.btnStatus);
        
        // Add button
        gitIntegration.btnAdd = app.CreateButton("Add All", 0.29, 0.08);
        gitIntegration.btnAdd.SetOnTouch(function() {
            gitIntegration.addAll();
        });
        layButtons.AddChild(gitIntegration.btnAdd);
        
        // Commit button
        gitIntegration.btnCommit = app.CreateButton("Commit", 0.29, 0.08);
        gitIntegration.btnCommit.SetOnTouch(function() {
            gitIntegration.commit();
        });
        layButtons.AddChild(gitIntegration.btnCommit);
        
        // Pull button
        gitIntegration.btnPull = app.CreateButton("Pull", 0.29, 0.08);
        gitIntegration.btnPull.SetOnTouch(function() {
            gitIntegration.pull();
        });
        layButtons.AddChild(gitIntegration.btnPull);
        
        // Push button
        gitIntegration.btnPush = app.CreateButton("Push", 0.29, 0.08);
        gitIntegration.btnPush.SetOnTouch(function() {
            gitIntegration.push();
        });
        layButtons.AddChild(gitIntegration.btnPush);
        
        // Log button
        gitIntegration.btnLog = app.CreateButton("Log", 0.29, 0.08);
        gitIntegration.btnLog.SetOnTouch(function() {
            gitIntegration.log();
        });
        layButtons.AddChild(gitIntegration.btnLog);
        
        // Add components to layout
        gitIntegration.layGit.AddChild(gitIntegration.txtBranch);
        gitIntegration.layGit.AddChild(gitIntegration.txtStatus);
        gitIntegration.layGit.AddChild(gitIntegration.txtOutput);
        gitIntegration.layGit.AddChild(layButtons);
        
        // Add layout to dialog
        gitIntegration.dlgGit.AddLayout(gitIntegration.layGit);
    };
    
    // Show Git panel
    this.showGitPanel = function() {
        // Refresh Git status before showing
        this.getStatus();
        
        // Show the dialog
        gitIntegration.dlgGit.Show();
    };
    
    // Get current Git status
    this.getStatus = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git status command
        app.SystemCmd("cd " + workingDir + " && git status", function(result) {
            gitIntegration.txtOutput.SetText(result);
        });
    };
    
    // Get current branch
    this.getCurrentBranch = function() {
        if (!gitIntegration.isGitInstalled) return;
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git branch command
        app.SystemCmd("cd " + workingDir + " && git branch --show-current", function(result) {
            gitIntegration.txtBranch.SetText("Branch: " + result.trim());
            gitIntegration.currentBranch = result.trim();
        });
    };
    
    // Add all files to Git
    this.addAll = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git add command
        app.SystemCmd("cd " + workingDir + " && git add .", function(result) {
            gitIntegration.txtOutput.SetText("Files added to staging area");
            gitIntegration.getStatus();
        });
    };
    
    // Commit changes
    this.commit = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Create commit message dialog
        var dlgCommit = app.CreateDialog("Commit Message");
        var layCommit = app.CreateLayout("Linear", "Vertical");
        
        // Create commit message input
        var edtCommit = app.CreateTextEdit("", 0.8, 0.2);
        edtCommit.SetHint("Enter commit message");
        
        // Create commit button
        var btnDoCommit = app.CreateButton("Commit", 0.8, 0.1);
        btnDoCommit.SetOnTouch(function() {
            var message = edtCommit.GetText();
            if (message.trim() === "") {
                app.ShowPopup("Please enter a commit message");
                return;
            }
            
            // Get current working directory
            var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
            var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
            
            // Execute Git commit command
            app.SystemCmd("cd " + workingDir + " && git commit -m \"" + message + "\"", function(result) {
                gitIntegration.txtOutput.SetText(result);
                dlgCommit.Dismiss();
            });
        });
        
        // Add components to layout
        layCommit.AddChild(edtCommit);
        layCommit.AddChild(btnDoCommit);
        
        // Add layout to dialog and show
        dlgCommit.AddLayout(layCommit);
        dlgCommit.Show();
    };
    
    // Pull changes from remote
    this.pull = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git pull command
        app.SystemCmd("cd " + workingDir + " && git pull", function(result) {
            gitIntegration.txtOutput.SetText(result);
        });
    };
    
    // Push changes to remote
    this.push = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git push command
        app.SystemCmd("cd " + workingDir + " && git push", function(result) {
            gitIntegration.txtOutput.SetText(result);
        });
    };
    
    // Show Git log
    this.log = function() {
        if (!gitIntegration.isGitInstalled) {
            gitIntegration.txtOutput.SetText("Git is not installed");
            return;
        }
        
        // Get current working directory
        var currentFile = app.LoadText("currentFile", "", "currentFile.txt");
        var workingDir = currentFile.substring(0, currentFile.lastIndexOf("/"));
        
        // Execute Git log command
        app.SystemCmd("cd " + workingDir + " && git log --oneline -n 10", function(result) {
            gitIntegration.txtOutput.SetText(result);
        });
    };
}
